"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

const handleValidate = (values, touched) => {
  const errors = {};
  const isRoutingTouched = touched.routingNumber;
  const isAccountTouched = touched.accountNumber;
  const isReenterAccountTouched = touched.reenterAccount;
  const isNicknameTouched = touched.nickname;

  if (isRoutingTouched) {
    if (values.routingNumber && values.routingNumber.toString().length !== 9) {
      errors.routingNumber = 'Your routing number must be 9 digits';
    }

    if (!values.routingNumber) {
      errors.routingNumber = 'Please enter your routing number';
    }
  }

  if (isAccountTouched) {
    if (!values.accountNumber) {
      errors.accountNumber = 'Please enter your account number';
    }

    if (values.accountNumber && values.accountNumber.toString().length > 17) {
      errors.accountNumber = 'Account number cannot be more than 17 digits';
    }
  }

  if (isReenterAccountTouched) {
    if (!values.reenterAccount) {
      errors.reenterAccount = 'Please re-enter your account number';
    }

    if (values.reenterAccount && values.reenterAccount.toString().length > 17) {
      errors.reenterAccount = 'Account number cannot be more than 17 digits';
    }
  }

  if (isAccountTouched && isReenterAccountTouched) {
    if (values.reenterAccount !== values.accountNumber) {
      errors.reenterAccount = 'Account numbers do not match';
    }
  }

  if (isNicknameTouched) {
    if (values.nickname && values.nickname.match(/^[A-Z]+$/i) === null) {
      errors.nickname = 'Account nickname cannot contain special characters or numbers';
    }
  }

  return errors;
};

var _default = handleValidate;
exports.default = _default;