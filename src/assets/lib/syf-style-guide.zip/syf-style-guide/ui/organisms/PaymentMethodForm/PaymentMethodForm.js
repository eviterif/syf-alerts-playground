"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _Textfield = _interopRequireDefault(require("../../atoms/Textfield"));

var _Small = _interopRequireDefault(require("../../typography/Small"));

var _Body = _interopRequireDefault(require("../../typography/Body"));

var _Error = _interopRequireDefault(require("../../icons/Error"));

var _Checkbox = _interopRequireDefault(require("../../atoms/Checkbox"));

var _defaultTheme = require("../../../defaultTheme");

var _routingAccountNumbers = _interopRequireDefault(require("../../assets/routing-account-numbers.png"));

var _mediaQueries = _interopRequireDefault(require("../../../mediaQueries"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const Container = _styledComponents.default.div.withConfig({
  displayName: "PaymentMethodForm__Container",
  componentId: "sc-1i661a-0"
})(["width:100%;"]);

const StyledInput = (0, _styledComponents.default)(_Textfield.default).withConfig({
  displayName: "PaymentMethodForm__StyledInput",
  componentId: "sc-1i661a-1"
})(["margin:24px 0 0;width:100%;"]);
const FirstInput = (0, _styledComponents.default)(_Textfield.default).withConfig({
  displayName: "PaymentMethodForm__FirstInput",
  componentId: "sc-1i661a-2"
})(["width:100%;margin:16px 0 0;"]);
const LastInput = (0, _styledComponents.default)(_Textfield.default).withConfig({
  displayName: "PaymentMethodForm__LastInput",
  componentId: "sc-1i661a-3"
})(["width:100%;margin:24px 0 ", ";"], props => props.hasMakeDefaultOption ? '0' : '32px');

const Wrapper = _styledComponents.default.div.withConfig({
  displayName: "PaymentMethodForm__Wrapper",
  componentId: "sc-1i661a-4"
})(["display:flex;flex-direction:column;@media ", "{flex-direction:row;justify-content:space-between;align-items:flex-start;}"], _mediaQueries.default.greaterThanMedium);

const InputWrapper = _styledComponents.default.div.withConfig({
  displayName: "PaymentMethodForm__InputWrapper",
  componentId: "sc-1i661a-5"
})(["display:block;width:100%;@media ", "{width:50%;}"], _mediaQueries.default.greaterThanMedium);

const ImageContainer = _styledComponents.default.div.withConfig({
  displayName: "PaymentMethodForm__ImageContainer",
  componentId: "sc-1i661a-6"
})(["width:100%;display:flex;justify-content:center;@media ", "{width:50%;}"], _mediaQueries.default.greaterThanMedium);

const ImageWrapper = _styledComponents.default.div.withConfig({
  displayName: "PaymentMethodForm__ImageWrapper",
  componentId: "sc-1i661a-7"
})(["display:block;width:100%;max-width:440px;margin-bottom:32px;@media ", "{margin-bottom:0;margin-left:16px;}"], _mediaQueries.default.greaterThanMedium);

const Image = _styledComponents.default.img.withConfig({
  displayName: "PaymentMethodForm__Image",
  componentId: "sc-1i661a-8"
})(["max-width:100%;max-height:100%;"]);

const StyledCheckbox = (0, _styledComponents.default)(_Checkbox.default).withConfig({
  displayName: "PaymentMethodForm__StyledCheckbox",
  componentId: "sc-1i661a-9"
})(["justify-content:flex-start;margin-bottom:32px;"]);

const ErrorIcon = () => {
  return React.createElement(_Error.default, {
    width: 13,
    height: 13,
    color: _defaultTheme.colors.error
  });
};

const PaymentMethodForm = ({
  className,
  formData,
  onChangeHandler,
  onBlurHandler,
  hasMakeDefaultOption = false,
  errors
}) => {
  return React.createElement(Container, {
    className: className
  }, React.createElement(_Body.default, {
    weight: "bold"
  }, "Add Payment Method"), React.createElement(Wrapper, null, React.createElement(InputWrapper, null, React.createElement(FirstInput, {
    id: "routing-number",
    placeholder: "Routing Number",
    value: formData.routingNumber,
    name: "routingNumber",
    type: "number",
    onChange: e => onChangeHandler(e),
    onBlur: e => onBlurHandler(e),
    error: errors.routingNumber,
    errorIcon: React.createElement(ErrorIcon, null)
  }), React.createElement(StyledInput, {
    id: "account-number",
    name: "accountNumber",
    placeholder: "Account Number",
    type: "number",
    value: formData.accountNumber,
    onChange: e => onChangeHandler(e),
    onBlur: e => onBlurHandler(e),
    error: errors.accountNumber,
    errorIcon: React.createElement(ErrorIcon, null)
  }), React.createElement(StyledInput, {
    id: "reenter-account-number",
    name: "reenterAccount",
    placeholder: "Re-Enter Account Number",
    type: "number",
    value: formData.reenterAccount,
    onChange: e => onChangeHandler(e),
    onBlur: e => onBlurHandler(e),
    error: errors.reenterAccount,
    errorIcon: React.createElement(ErrorIcon, null)
  }), React.createElement(LastInput, {
    id: "nickname",
    name: "nickname",
    placeholder: "Account Nickname (Optional)",
    value: formData.nickname,
    onChange: e => onChangeHandler(e),
    onBlur: e => onBlurHandler(e),
    type: "text",
    maxLength: 32,
    error: errors.nickname,
    errorIcon: React.createElement(ErrorIcon, null)
  }), hasMakeDefaultOption && React.createElement(StyledCheckbox, {
    onChange: e => onChangeHandler(e),
    checked: formData.makeDefault,
    name: "makeDefault"
  }, "Make this my default payment method")), React.createElement(ImageContainer, null, React.createElement(ImageWrapper, null, React.createElement(Image, {
    src: _routingAccountNumbers.default,
    alt: "The routing number and account number are located below the Memo field in the lower left corner."
  })))), React.createElement(_Small.default, null, "I authorize Synchrony Bank to initiate electronic payment when I submit online payment requests using the bank account indicated above, and I authorize my bank to honor the withdrawals. This authorization pertains to the loan account noted above and is to remain in effect until it is canceled by Synchrony Bank, my financial institution, or me."), React.createElement("br", null), React.createElement(_Small.default, null, "There will be no funds transfer at this time. The authorization of your bank to transfer funds to your loan account account occurs only when you complete a payment request."));
};

var _default = PaymentMethodForm;
exports.default = _default;