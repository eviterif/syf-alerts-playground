"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TableHeaderRow = exports.TableRow = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const TR = _styledComponents.default.tr.withConfig({
  displayName: "TableRow__TR",
  componentId: "sc-10962ji-0"
})(["", " ", ""], props => props.onClick && "\n    &:hover {\n      background-color: ".concat(props.theme.dataTable.hover, ";\n      cursor: pointer;\n    }\n  "), props => props.breakpoint && "\n    @media (max-width: ".concat(props.breakpoint, "px) {\n      border-bottom: 1px solid ").concat(_defaultTheme.colors.lightGrey, ";\n      display: flex;\n      flex-direction: column;\n      position: relative;\n\n      td:first-of-type  {\n        padding: 12px;\n      }\n    }\n  "));

const THR = (0, _styledComponents.default)(TR).withConfig({
  displayName: "TableRow__THR",
  componentId: "sc-10962ji-1"
})(["", ""], props => props.breakpoint && "\n    @media (max-width: ".concat(props.breakpoint, "px) {\n      display: none;\n    }\n  "));

const TableRow = (_ref) => {
  let className = _ref.className,
      _ref$onClick = _ref.onClick,
      onClick = _ref$onClick === void 0 ? null : _ref$onClick,
      _ref$breakpoint = _ref.breakpoint,
      breakpoint = _ref$breakpoint === void 0 ? 0 : _ref$breakpoint,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, ["className", "onClick", "breakpoint", "children"]);

  return React.createElement(TR, _extends({
    className: className,
    breakpoint: breakpoint,
    onClick: onClick
  }, props), children);
};

exports.TableRow = TableRow;

const TableHeaderRow = (_ref2) => {
  let className = _ref2.className,
      _ref2$breakpoint = _ref2.breakpoint,
      breakpoint = _ref2$breakpoint === void 0 ? 0 : _ref2$breakpoint,
      _ref2$onClick = _ref2.onClick,
      onClick = _ref2$onClick === void 0 ? null : _ref2$onClick,
      children = _ref2.children,
      props = _objectWithoutProperties(_ref2, ["className", "breakpoint", "onClick", "children"]);

  return React.createElement(THR, _extends({
    className: className,
    breakpoint: breakpoint,
    onClick: onClick
  }, props), children);
};

exports.TableHeaderRow = TableHeaderRow;