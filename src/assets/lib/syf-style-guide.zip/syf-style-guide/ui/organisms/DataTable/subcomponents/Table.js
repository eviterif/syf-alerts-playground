"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const Table = _styledComponents.default.table.withConfig({
  displayName: "Table",
  componentId: "sc-1udkycy-0"
})(["border-radius:5px;width:100%;padding:0;overflow:hidden;border:solid 1px ", ";border-collapse:separate;border-spacing:0;", " ", ""], _defaultTheme.colors.lightGrey, props => {
  return props.isCardTable ? "background-color: inherit;" : "\n        background-color: ".concat(_defaultTheme.colors.lightestGrey, ";\n        border: solid 1px ").concat(_defaultTheme.colors.lightGrey, ";\n      ");
}, props => {
  return props.breakpoint && "\n        @media (max-width: ".concat(props.breakpoint, "px) {\n          ").concat(props.isCardTable && "border: none;", "\n        }\n      ");
});

const TableComponent = ({
  isCardTable,
  breakpoint = 0,
  children,
  className
}) => React.createElement(Table, {
  isCardTable: isCardTable,
  breakpoint: breakpoint,
  className: className
}, children);

var _default = TableComponent;
exports.default = _default;