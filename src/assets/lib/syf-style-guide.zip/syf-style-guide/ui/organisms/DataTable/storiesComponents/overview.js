"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _react = _interopRequireDefault(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _reactFontawesome = require("@fortawesome/react-fontawesome");

var _freeSolidSvgIcons = require("@fortawesome/free-solid-svg-icons");

var _Card = require("../../../atoms/Card");

var _ = _interopRequireDefault(require(".."));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _default() {
  const Btn = _styledComponents.default.button.withConfig({
    displayName: "overview__Btn",
    componentId: "rngcmv-0"
  })(["color:", ";font-weight:bold;"], props => props.color);

  const fn = e => {
    e.stopPropagation();
    alert('button click!');
  };

  const Details = () => _react.default.createElement(Btn, {
    color: "green",
    onClick: fn
  }, "Details");

  const Delete = () => _react.default.createElement(Btn, {
    color: "red",
    onClick: fn
  }, "Delete");

  const rowClickFn = (row, rowIndex) => {
    alert("clicked row ".concat(rowIndex, "!"));
  };

  const data = [['Nickname', 'Account #', 'Balance', 'Bank', '', ''], ['Personal', 3917502, {
    value: '$-12.82',
    isPrimaryCell: true
  }, 'Chase', {
    value: _react.default.createElement(Details, null),
    hideInMobile: true
  }, {
    value: _react.default.createElement(Delete, null),
    hideInMobile: true
  }], ['Retirement', 2951047, {
    value: '$1032',
    isPrimaryCell: true
  }, 'Synchrony', {
    value: _react.default.createElement(Details, null),
    hideInMobile: true
  }, {
    value: _react.default.createElement(Delete, null),
    hideInMobile: true
  }]];
  return _react.default.createElement("div", null, _react.default.createElement("div", {
    style: {
      paddingBottom: '16px'
    }
  }, "Default Table", _react.default.createElement(_.default, {
    tableData: data,
    onRowClick: rowClickFn,
    rowClickIcon: _react.default.createElement(_reactFontawesome.FontAwesomeIcon, {
      icon: _freeSolidSvgIcons.faChevronRight
    })
  })), _react.default.createElement("div", {
    style: {
      width: '48%'
    }
  }, "Mobile Default Table", _react.default.createElement(_.default, {
    breakpoint: 2000,
    tableData: data,
    onRowClick: rowClickFn,
    rowClickIcon: _react.default.createElement(_reactFontawesome.FontAwesomeIcon, {
      icon: _freeSolidSvgIcons.faCheck
    })
  })), _react.default.createElement("div", {
    style: {
      width: '48%'
    }
  }, _react.default.createElement(_Card.Card, {
    isInline: true,
    width: "48%",
    title: "Mobile CardTable"
  }, _react.default.createElement(_.default, {
    breakpoint: 2000,
    isCardTable: true,
    tableData: data,
    onRowClick: rowClickFn,
    rowClickIcon: _react.default.createElement(_reactFontawesome.FontAwesomeIcon, {
      icon: _freeSolidSvgIcons.faChevronRight
    })
  }))));
}