"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.TableRowIcon = exports.TableCellContent = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const TD = _styledComponents.default.td.withConfig({
  displayName: "TableCell__TD",
  componentId: "sc-1rmxzod-0"
})(["text-align:", ";padding:12px 24px;.DataTable__cell-label{display:none;}", " ", ""], props => props.align || 'left', props => props.isCardTable && "border-bottom: 1px solid ".concat(_defaultTheme.colors.lightGrey, ";"), props => {
  return props.breakpoint && "\n      @media (max-width: ".concat(props.breakpoint, "px) {\n        border: none;\n        padding: 4px 12px 12px;\n        display: ").concat(props.hideInMobile ? 'none' : 'block', ";\n\n        ").concat(props.isPrimaryCell ? "\n            position: absolute;\n            right: 0;\n            top: 12px;\n            font-weight: ".concat(_defaultTheme.fontWeights.bold, ";\n        ") : "\n            .DataTable__cell-label {\n              display: block;\n\n              font-weight: ".concat(_defaultTheme.fontWeights.bold, ";\n            }\n        "), "\n      }\n    ");
});

const TableCellContent = ({
  content
}) => React.createElement(React.Fragment, null, content.value || content || ' ');

exports.TableCellContent = TableCellContent;

const TableCell = (_ref) => {
  let className = _ref.className,
      cellData = _ref.cellData,
      _ref$breakpoint = _ref.breakpoint,
      breakpoint = _ref$breakpoint === void 0 ? 0 : _ref$breakpoint,
      isCardTable = _ref.isCardTable,
      label = _ref.label,
      props = _objectWithoutProperties(_ref, ["className", "cellData", "breakpoint", "isCardTable", "label"]);

  const cellConfig = cellData.value ? cellData.value : false;
  return cellConfig ? React.createElement(TD, _extends({
    className: className,
    breakpoint: breakpoint,
    hideInMobile: cellData.hideInMobile,
    isCardTable: isCardTable,
    isPrimaryCell: cellData.isPrimaryCell,
    align: cellData.align,
    colspan: cellData.colspan || '1'
  }, props), label && !isCardTable && React.createElement("div", {
    className: "DataTable__cell-label"
  }, React.createElement(TableCellContent, {
    content: label
  })), React.createElement(TableCellContent, {
    content: cellData
  })) : React.createElement(TD, _extends({
    className: className,
    breakpoint: breakpoint,
    isCardTable: isCardTable
  }, props), label && !isCardTable && React.createElement("div", {
    className: "DataTable__cell-label"
  }, React.createElement(TableCellContent, {
    content: label
  })), React.createElement(TableCellContent, {
    content: cellData
  }));
};

const TableRowIcon = (0, _styledComponents.default)(TableCell).withConfig({
  displayName: "TableCell__TableRowIcon",
  componentId: "sc-1rmxzod-1"
})(["padding:0 12px 0 0;width:30px;& *{vertical-align:middle;}", ""], props => props.breakpoint && "\n      @media (max-width: ".concat(props.breakpoint, "px) {\n        text-align: right;\n        position: absolute;\n        top: 45%;\n        right: 0;\n        border: none;\n      }\n    "));
exports.TableRowIcon = TableRowIcon;
var _default = TableCell;
exports.default = _default;