"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _subcomponents = require("./subcomponents");

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const DataTable = ({
  className,
  tableData,
  isCardTable,
  breakpoint = 0,
  onRowClick = null,
  rowClickIcon = null
}) => React.createElement(_subcomponents.Table, {
  className: className,
  isCardTable: isCardTable,
  breakpoint: breakpoint
}, React.createElement("thead", null, React.createElement(_subcomponents.TableHeaderRow, {
  breakpoint: breakpoint
}, tableData[0].map((cell, cellIndex) => React.createElement(_subcomponents.TableHeader, {
  isCardTable: isCardTable,
  cellData: cell,
  key: "".concat(cellIndex + 1)
})), onRowClick ? React.createElement(_subcomponents.TableHeader, {
  isCardTable: isCardTable,
  cellData: ""
}) : null)), React.createElement("tbody", null, tableData.map((row, rowIndex) => {
  if (rowIndex > 0) {
    return React.createElement(_subcomponents.TableRow, {
      key: "".concat(rowIndex + 1),
      breakpoint: breakpoint,
      onClick: onRowClick ? () => onRowClick(row, rowIndex) : null
    }, row.map((cell, cellIndex) => React.createElement(_subcomponents.TableCell, {
      breakpoint: breakpoint,
      isCardTable: isCardTable,
      cellData: cell,
      label: tableData[0][cellIndex],
      key: "".concat(cellIndex + 1)
    })), onRowClick ? React.createElement(_subcomponents.TableRowIcon, {
      className: "tablerow-icon",
      hasRowClickIcon: !!rowClickIcon,
      isCardTable: isCardTable,
      breakpoint: breakpoint,
      cellData: rowClickIcon || '>'
    }) : null);
  }

  return null;
})));

var _default = DataTable;
exports.default = _default;