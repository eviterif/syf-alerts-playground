"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _mediaQueries = _interopRequireDefault(require("../../../mediaQueries"));

var _Small = _interopRequireDefault(require("../../typography/Small"));

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const FooterWrapper = _styledComponents.default.div.withConfig({
  displayName: "Footer__FooterWrapper",
  componentId: "sc-17zivkt-0"
})(["padding:16px 16px 16px;clear:both;font-size:", "px;line-height:", ";color:", ";font-family:'Open Sans';"], _defaultTheme.fontSizes.small, _defaultTheme.lineHeights.largest, _defaultTheme.colors.black);

const StyledKey = _styledComponents.default.div.withConfig({
  displayName: "Footer__StyledKey",
  componentId: "sc-17zivkt-1"
})(["display:flex;flex-direction:column;justify-content:flex-start;@media ", "{flex-direction:row;}"], _mediaQueries.default.greaterThanMedium);

const SelectedDate = _styledComponents.default.div.withConfig({
  displayName: "Footer__SelectedDate",
  componentId: "sc-17zivkt-2"
})(["display:flex;flex-direction:row;align-items:center;margin-bottom:14px;::before{margin-right:8px;content:'';display:inline-block;height:23px;width:23px;border-radius:3.6px;background-color:", ";}@media ", "{margin-right:40px;margin-bottom:0;}"], props => props.theme.datepicker.selectedDate, _mediaQueries.default.greaterThanMedium);

const DueDate = _styledComponents.default.div.withConfig({
  displayName: "Footer__DueDate",
  componentId: "sc-17zivkt-3"
})(["display:flex;flex-direction:row;align-items:center;::before{margin-right:8px;display:inline-block;content:'';height:23px;width:23px;border-radius:3.6px;border:solid 2px ", ";}"], props => props.theme.datepicker.dueDate);

const StyledDisclaimer = (0, _styledComponents.default)(_Small.default).withConfig({
  displayName: "Footer__StyledDisclaimer",
  componentId: "sc-17zivkt-4"
})(["max-width:225px;margin-top:16px;@media ", "{max-width:450px;}"], _mediaQueries.default.greaterThanMedium);

const Footer = ({
  hasKey = true,
  disclaimerCopy,
  className
}) => {
  return React.createElement(FooterWrapper, {
    className: className
  }, hasKey && React.createElement(StyledKey, null, React.createElement(SelectedDate, null, "Selected payment date"), React.createElement(DueDate, null, "Due date")), React.createElement(StyledDisclaimer, null, disclaimerCopy));
};

var _default = Footer;
exports.default = _default;