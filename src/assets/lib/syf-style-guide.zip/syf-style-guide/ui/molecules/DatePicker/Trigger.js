"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _dateFns = require("date-fns");

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const LeftIconWrapper = _styledComponents.default.div.withConfig({
  displayName: "Trigger__LeftIconWrapper",
  componentId: "sc-1eplwot-0"
})(["display:flex;justify-content:center;align-items:center;margin-right:13px;"]);

const InputWrapper = _styledComponents.default.div.withConfig({
  displayName: "Trigger__InputWrapper",
  componentId: "sc-1eplwot-1"
})(["color:", ";display:flex;align-items:center;border-radius:6px;background-color:", ";padding:4px 16px;", " box-shadow:", ";"], props => props.theme.field.label, _defaultTheme.colors.white, props => !props.isOpen ? "\n      &:hover {\n        box-shadow: 0 0 0 1px ".concat(props.theme.field.focus, ";\n      }\n    ") : '', props => props.isOpen ? "0 0 0 2px ".concat(props.theme.field.focus) : "0 0 0 1px ".concat(_defaultTheme.colors.heavyGrey));

const Container = _styledComponents.default.div.withConfig({
  displayName: "Trigger__Container",
  componentId: "sc-1eplwot-2"
})(["text-align:left;height:48px;width:100%;"]);

const StyledLabel = _styledComponents.default.label.withConfig({
  displayName: "Trigger__StyledLabel",
  componentId: "sc-1eplwot-3"
})(["font-size:", "px;color:", ";"], _defaultTheme.fontSizes.small, props => props.theme.field.label);

const CopyWrapper = _styledComponents.default.div.withConfig({
  displayName: "Trigger__CopyWrapper",
  componentId: "sc-1eplwot-4"
})(["display:flex;flex-direction:column;"]);

const StyledInput = _styledComponents.default.input.withConfig({
  displayName: "Trigger__StyledInput",
  componentId: "sc-1eplwot-5"
})(["color:transparent;text-shadow:0 0 0 ", ";font-size:", "px;border:none;&:focus{outline:none;}"], _defaultTheme.colors.black, _defaultTheme.fontSizes.root);

const ChevronWrapper = _styledComponents.default.div.withConfig({
  displayName: "Trigger__ChevronWrapper",
  componentId: "sc-1eplwot-6"
})(["color:inherit;position:absolute;right:16px;"]); // forwardRef is needed here to avoid a react error coming from datepicker lib
// flow does not play nice with refs and function components :(
// $FlowIssue


const CustomTrigger = React.forwardRef((_ref, ref) => {
  let _ref$value = _ref.value,
      value = _ref$value === void 0 ? '0' : _ref$value,
      onClick = _ref.onClick,
      leftIcon = _ref.leftIcon,
      label = _ref.label,
      isOpen = _ref.isOpen,
      className = _ref.className,
      closeIcon = _ref.closeIcon,
      openIcon = _ref.openIcon,
      props = _objectWithoutProperties(_ref, ["value", "onClick", "leftIcon", "label", "isOpen", "className", "closeIcon", "openIcon"]);

  const isToday = value === (0, _dateFns.format)(new Date(), 'MM/dd/yyyy');
  const displayDate = (0, _dateFns.format)(new Date(value), 'MMM dd, yyyy');
  const displayValue = "".concat(displayDate, " ").concat(isToday ? '(Today)' : '');
  return React.createElement(Container, _extends({
    ref: ref,
    onClick: onClick // necessary to prevent calendar from opening/closing when input is clicked
    ,
    className: "react-datepicker-ignore-onclickoutside ".concat(className || '')
  }, props), React.createElement(InputWrapper, {
    leftIcon: leftIcon,
    isOpen: isOpen
  }, leftIcon && React.createElement(LeftIconWrapper, null, leftIcon), React.createElement(CopyWrapper, null, React.createElement(StyledLabel, null, label), React.createElement(StyledInput, {
    leftIcon: leftIcon,
    isOpen: isOpen,
    value: displayValue,
    onChange: () => null
  })), openIcon && closeIcon && React.createElement(ChevronWrapper, null, isOpen ? openIcon : closeIcon)));
});
var _default = CustomTrigger;
exports.default = _default;