"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

const Chevron = _styledComponents.default.span.withConfig({
  displayName: "Tab__Chevron",
  componentId: "sc-1fqdcgt-0"
})(["::before{color:", ";border-style:solid;border-width:2px 2px 0 0;content:'';display:inline-block;height:5px;left:10px;position:relative;top:0.15em;transform:rotate(-45deg);vertical-align:top;width:5px;top:4px;transform:rotate(135deg);}"], props => props.theme.icon);

const ListItem = _styledComponents.default.li.withConfig({
  displayName: "Tab__ListItem",
  componentId: "sc-1fqdcgt-1"
})(["min-width:150px;display:flex;justify-content:center;align-items:center;padding:10px;position:relative;cursor:pointer;color:", ";"], props => props.showActiveStyles ? "".concat(props.theme.navigation.activeTabText) : 'inherit');

const TabButton = _styledComponents.default.button.withConfig({
  displayName: "Tab__TabButton",
  componentId: "sc-1fqdcgt-2"
})(["outline:none;background-color:transparent;border:none;font-size:", "px;line-height:", ";color:", ";font-weight:", ";cursor:pointer;padding:0;border-bottom:", ";&:hover{border-bottom:", ""], _defaultTheme.fontSizes.root, _defaultTheme.lineHeights.root, props => props.showActiveStyles ? "".concat(props.theme.navigation.activeTabText) : 'inherit', props => props.showActiveStyles ? 'bold' : 'normal', props => props.showActiveStyles ? "2px solid ".concat(props.theme.navigation.activeTabBorder) : '2px solid transparent', props => "2px solid ".concat(props.theme.navigation.activeTabBorder));

const Tab = props => {
  const handleTabClick = props.handleTabClick,
        activePanel = props.activePanel,
        label = props.label,
        index = props.index,
        handleComplexTab = props.handleComplexTab,
        _props$isComplexActiv = props.isComplexActive,
        isComplexActive = _props$isComplexActiv === void 0 ? false : _props$isComplexActiv,
        _props$withChevron = props.withChevron,
        withChevron = _props$withChevron === void 0 ? false : _props$withChevron,
        className = props.className;

  const shouldShowActiveStyles = () => {
    const isActivePanel = activePanel === index && !handleComplexTab;
    return isActivePanel || isComplexActive;
  };

  const _React$useState = React.useState(shouldShowActiveStyles()),
        _React$useState2 = _slicedToArray(_React$useState, 2),
        showActiveStyles = _React$useState2[0],
        setShowActiveStyles = _React$useState2[1];

  React.useEffect(() => {
    setShowActiveStyles(shouldShowActiveStyles());
  }, [activePanel, isComplexActive]);

  const onTabClick = () => {
    if (handleComplexTab) {
      handleComplexTab();
    } else if (handleTabClick) {
      handleTabClick(index);
    }
  };

  return React.createElement(TabButton, {
    showActiveStyles: showActiveStyles,
    onClick: onTabClick
  }, React.createElement(ListItem, {
    showActiveStyles: showActiveStyles,
    className: className
  }, label, withChevron && React.createElement(Chevron, null)));
};

var _default = Tab;
exports.default = _default;