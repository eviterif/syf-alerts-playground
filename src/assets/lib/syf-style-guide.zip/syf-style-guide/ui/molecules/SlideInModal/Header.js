"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _H = _interopRequireDefault(require("../../typography/H5"));

var _Close = _interopRequireDefault(require("../../icons/Close"));

var _Button = _interopRequireDefault(require("../../atoms/Button"));

var _defaultTheme = require("../../../defaultTheme");

var _mediaQueries = _interopRequireDefault(require("../../../mediaQueries"));

var _SlideInModal = require("./SlideInModal");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const StyledTitle = (0, _styledComponents.default)(_H.default).withConfig({
  displayName: "Header__StyledTitle",
  componentId: "sc-1p94xvv-0"
})(["line-height:32px;"]);

const StyledHeader = _styledComponents.default.div.withConfig({
  displayName: "Header__StyledHeader",
  componentId: "sc-1p94xvv-1"
})(["justify-content:space-between;padding:0 16px;height:56px;flex-direction:row;background:", ";border-bottom:1px solid ", ";", " @media ", "{padding:0px 24px;}"], _defaultTheme.colors.lightestGrey, _defaultTheme.colors.lightGrey, _SlideInModal.sharedElementStyles, _mediaQueries.default.greaterThanMedium);

const StyledClose = (0, _styledComponents.default)(_Button.default).withConfig({
  displayName: "Header__StyledClose",
  componentId: "sc-1p94xvv-2"
})(["margin:0;padding:0;"]);

const ModalHeader = ({
  hideClose,
  closeModal,
  content,
  headerRef
}) => {
  return React.createElement(StyledHeader, null, React.createElement(StyledTitle, {
    tabIndex: -1,
    ref: headerRef
  }, content), !hideClose && React.createElement(StyledClose, {
    buttonType: "text",
    onClick: () => closeModal && closeModal()
  }, React.createElement(_Close.default, {
    height: "14px",
    width: "14px"
  })));
};

var _default = ModalHeader;
exports.default = _default;