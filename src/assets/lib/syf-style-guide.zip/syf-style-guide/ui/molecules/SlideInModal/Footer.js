"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _Button = _interopRequireDefault(require("../../atoms/Button"));

var _defaultTheme = require("../../../defaultTheme");

var _mediaQueries = _interopRequireDefault(require("../../../mediaQueries"));

var _SlideInModal = require("./SlideInModal");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const footerButtonStyles = "\n  margin: 0;\n  min-width: 100%;\n\n  @media ".concat(_mediaQueries.default.greaterThanMedium, " {\n    min-width: 120px;\n  }\n");

const StyledFooter = _styledComponents.default.div.withConfig({
  displayName: "Footer__StyledFooter",
  componentId: "ua9ij7-0"
})(["padding:0px 16px;background:", ";", " height:152px;flex-direction:column-reverse;justify-content:center;border-top:1px solid ", ";button:nth-child(2){margin-bottom:8px;}@media ", "{height:96px;padding:0 24px;flex-direction:row;justify-content:flex-end;button:nth-child(2){margin-bottom:0;margin-left:8px;}}"], _defaultTheme.colors.lightestGrey, _SlideInModal.sharedElementStyles, _defaultTheme.colors.lightGrey, _mediaQueries.default.greaterThanMedium);

const CancelButton = (0, _styledComponents.default)(_Button.default).withConfig({
  displayName: "Footer__CancelButton",
  componentId: "ua9ij7-1"
})(["background-color:inherit;", ""], footerButtonStyles);
const ConfirmButton = (0, _styledComponents.default)(_Button.default).withConfig({
  displayName: "Footer__ConfirmButton",
  componentId: "ua9ij7-2"
})(["", ""], footerButtonStyles);

const ModalFooter = ({
  cancelText = 'CANCEL',
  confirmText = 'CONFIRM',
  handleCancel,
  handleConfirm
}) => {
  return React.createElement(StyledFooter, null, React.createElement(CancelButton, {
    buttonType: "ghost",
    onClick: handleCancel
  }, cancelText), React.createElement(ConfirmButton, {
    buttonType: "primary",
    onClick: handleConfirm
  }, confirmText));
};

var _default = ModalFooter;
exports.default = _default;