"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.sharedElementStyles = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _focusTrapReact = _interopRequireDefault(require("focus-trap-react"));

var _defaultTheme = require("../../../defaultTheme");

var _mediaQueries = _interopRequireDefault(require("../../../mediaQueries"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

// shared header/footer styles
const sharedElementStyles = "\n  display: flex;\n  align-items: center;\n  width: calc(100vw - 32px);\n\n  @media ".concat(_mediaQueries.default.greaterThanMedium, " {\n    max-width: calc(768px - 48px);\n  }\n"); // darkened overlay styles - need to use pseudo element

exports.sharedElementStyles = sharedElementStyles;

const Overlay = _styledComponents.default.div.withConfig({
  displayName: "SlideInModal__Overlay",
  componentId: "bty89f-0"
})(["", ""], props => props.isOpen && "\n    :after {\n      content: \"\";\n      display: block;\n      position: fixed; \n      top: 0;\n      left: 0;\n      height: 100%;\n      width: 100%;\n      z-index: 1;\n      background-color: rgba(0,0,0,0.5);\n    }\n  ");

const ModalWrapper = _styledComponents.default.div.withConfig({
  displayName: "SlideInModal__ModalWrapper",
  componentId: "bty89f-1"
})(["position:fixed;right:-768px;top:0;z-index:2;background-color:", ";width:100vw;overflow-y:auto;height:100vh;max-height:100vh;transition:right 400ms ease-in-out;@media ", "{max-width:768px;}"], _defaultTheme.colors.white, _mediaQueries.default.greaterThanMedium);

const ModalContent = _styledComponents.default.div.withConfig({
  displayName: "SlideInModal__ModalContent",
  componentId: "bty89f-2"
})(["padding:16px;min-height:calc(100% - 242px);@media ", "{min-height:calc(100% - 202px);padding:24px;}"], _mediaQueries.default.greaterThanMedium);

const SlideInModal = ({
  isOpen,
  children,
  header,
  className,
  footer,
  headerRef
}) => {
  const _React$useState = React.useState(false),
        _React$useState2 = _slicedToArray(_React$useState, 2),
        postAnimationState = _React$useState2[0],
        setPostAnimationState = _React$useState2[1];

  React.useEffect(() => {
    // set focus to the header when modal is opened
    if (isOpen && headerRef.current) {
      headerRef.current.focus(); // React Ref wasn't working for this case

      document.querySelector('#modal-wrapper').style.right = '0px';
      document.body.style.overflow = 'hidden';
      setPostAnimationState(true);
    }

    if (!isOpen && document.querySelector('#modal-wrapper')) {
      // React Ref wasn't working for this case
      document.body.style.overflow = 'auto';
      document.querySelector('#modal-wrapper').style.right = '-768px';
      setTimeout(() => {
        setPostAnimationState(false);
      }, 400);
    }
  }, [isOpen, headerRef]);
  return React.createElement(Overlay, {
    isOpen: postAnimationState
  }, (isOpen || postAnimationState) && React.createElement(_focusTrapReact.default, {
    active: postAnimationState
  }, React.createElement(ModalWrapper, {
    role: "dialog",
    id: "modal-wrapper",
    className: className
  }, header && header, React.createElement(ModalContent, {
    ref: !header ? headerRef : null
  }, children), footer && footer)));
};

var _default = SlideInModal;
exports.default = _default;