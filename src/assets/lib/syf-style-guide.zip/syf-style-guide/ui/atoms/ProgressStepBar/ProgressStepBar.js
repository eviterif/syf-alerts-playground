"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _react = _interopRequireDefault(require("react"));

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const ProgressStepBarBase = _styledComponents.default.ul.withConfig({
  displayName: "ProgressStepBar__ProgressStepBarBase",
  componentId: "h3tvxb-0"
})(["width:", "px;display:flex;flex-direction:row;justify-content:stretch;position:relative;"], props => props.width);

const Step = _styledComponents.default.li.withConfig({
  displayName: "ProgressStepBar__Step",
  componentId: "h3tvxb-1"
})(["list-style-type:none;float:left;font-family:Open Sans;font-size:", "px;color:", ";flex:1;text-align:center;position:relative;&:before{content:'';width:", "px;height:", "px;display:block;text-align:center;border-radius:50%;", " ", "}&:not(:first-of-type):after{background-color:", ";position:absolute;float:left;content:'';width:100%;height:4px;left:-50%;top:", "px;z-index:-1;}", ""], _defaultTheme.fontSizes.root, props => props.currentStep ? _defaultTheme.colors.black : _defaultTheme.colors.mediumGrey, props => props.circleRadius * 2, props => props.circleRadius * 2, props => props.currentStep && "box-shadow: 0px 0px 0px 4px ".concat(props.theme.progressStepBar.fill, ";"), props => !props.isSurpassed ? "\n        border: 4px solid ".concat(props.theme.progressStepBar.fill, ";\n        background-color: ").concat(_defaultTheme.colors.white, ";\n        margin: 0 auto 10px auto;\n      ") : "\n        background-color: ".concat(_defaultTheme.colors.mediumGrey, ";\n        margin: 4px auto 14px auto;\n      "), props => !props.isSurpassed ? props.theme.progressStepBar.fill : _defaultTheme.colors.lightGrey, props => props.circleRadius + 2, props => props.onClick && "\n      &:hover:before {\n        box-shadow: 0px 0px 1px 4px\n          ".concat(!props.isSurpassed ? props.theme.progressStepBar.hover : 'transparent', ";\n      }\n      &:hover {\n        cursor: pointer;\n        color: ").concat(_defaultTheme.colors.black, ";\n      }\n    "));

const ProgressStepBar = props => {
  const steps = props.steps,
        _props$width = props.width,
        width = _props$width === void 0 ? 300 : _props$width,
        _props$circleRadius = props.circleRadius,
        circleRadius = _props$circleRadius === void 0 ? 4 : _props$circleRadius,
        onClick = props.onClick,
        className = props.className;
  return _react.default.createElement(ProgressStepBarBase, {
    width: width,
    "data-test": "progress-step-bar",
    className: className
  }, steps.map((step, index) => {
    const currentStep = !step.isSurpassed && (steps.length === index + 1 || steps[index + 1].isSurpassed);
    return _react.default.createElement(Step, {
      isSurpassed: step.isSurpassed,
      currentStep: currentStep,
      key: step.label,
      value: step.value,
      "data-test": "progress-step",
      circleRadius: circleRadius,
      onClick: onClick && (e => onClick(e, step.value))
    }, step.label);
  }));
};

var _default = ProgressStepBar;
exports.default = _default;