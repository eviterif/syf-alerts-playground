"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../../defaultTheme");

var _Small = _interopRequireDefault(require("../../typography/Small"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const StyledTag = _styledComponents.default.span.withConfig({
  displayName: "Tag__StyledTag",
  componentId: "sc-1ev3v70-0"
})(["border-radius:500px;color:", ";background-color:", ";display:inline-flex;align-items:center;padding:5px 12px 7px;font-weight:", ";"], props => props.textColor, props => props.backgroundColor, _defaultTheme.fontWeights.semiBold);

const IconWrapper = _styledComponents.default.span.withConfig({
  displayName: "Tag__IconWrapper",
  componentId: "sc-1ev3v70-1"
})(["margin-right:8px;display:flex;"]);

const Tag = (_ref) => {
  let icon = _ref.icon,
      backgroundColor = _ref.backgroundColor,
      content = _ref.content,
      _ref$textColor = _ref.textColor,
      textColor = _ref$textColor === void 0 ? _defaultTheme.colors.charcoal : _ref$textColor,
      props = _objectWithoutProperties(_ref, ["icon", "backgroundColor", "content", "textColor"]);

  return React.createElement(StyledTag, _extends({
    backgroundColor: backgroundColor,
    textColor: textColor
  }, props), icon && React.createElement(IconWrapper, {
    className: "Tag__icon-wrapper"
  }, icon), React.createElement(_Small.default, {
    isInline: true,
    className: "Tag__content"
  }, content));
};

var _default = Tag;
exports.default = _default;