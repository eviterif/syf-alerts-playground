"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.Card = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _H = _interopRequireDefault(require("../../typography/H5"));

var _defaultTheme = require("../../../defaultTheme");

var _CardRow = _interopRequireDefault(require("./CardRow"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const CardBase = _styledComponents.default.div.withConfig({
  displayName: "Card__CardBase",
  componentId: "sc-1n2hz7r-0"
})(["overflow:hidden;background-color:", ";border-radius:10px;box-shadow:0 1px 10px 0 rgba(0,0,0,0.1),0 4px 5px 0 rgba(0,0,0,0.08),0 2px 4px 0 rgba(0,0,0,0.04);display:block;width:100%;"], _defaultTheme.colors.white);

const Header = (0, _styledComponents.default)(_CardRow.default).withConfig({
  displayName: "Card__Header",
  componentId: "sc-1n2hz7r-1"
})(["padding:8px 16px;"]);
const Title = (0, _styledComponents.default)(_H.default).withConfig({
  displayName: "Card__Title",
  componentId: "sc-1n2hz7r-2"
})(["text-transform:uppercase;color:", ";margin:0;line-height:32px;"], _defaultTheme.colors.black);

const Content = _styledComponents.default.div.withConfig({
  displayName: "Card__Content",
  componentId: "sc-1n2hz7r-3"
})(["margin:0;"]);

const Card = ({
  title = '',
  children,
  className,
  titleSibling
}) => React.createElement(CardBase, {
  className: className
}, title && React.createElement(Header, {
  hasBorderBottom: true,
  "data-test": "card-header"
}, React.createElement(Title, {
  weight: "light"
}, title), titleSibling || null), React.createElement(Content, {
  className: "content"
}, children));

exports.Card = Card;
var _default = Card;
exports.default = _default;