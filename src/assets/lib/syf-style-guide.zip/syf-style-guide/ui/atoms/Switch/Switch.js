"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const SwitchInput = _styledComponents.default.input.withConfig({
  displayName: "Switch__SwitchInput",
  componentId: "sc-3ijad1-0"
})(["appearance:none;z-index:-1;position:absolute;right:6px;top:-8px;display:block;margin:0;border-radius:50%;width:40px;height:40px;outline:none;opacity:0;transform:scale(1);background-color:transparent;pointer-events:none;transition:opacity 0.3s 0.1s,transform 0.2s 0.1s;&:checked{transform:translateX(16px);}&:focus:checked{background-color:", ";opacity:", ";}&:focus:not(:checked){background-color:", ";opacity:", ";z-index:0;}"], props => props.theme.switch.background, _defaultTheme.opacities.light24, _defaultTheme.colors.heavyGrey, _defaultTheme.opacities.light38);

const SwitchContainer = _styledComponents.default.label.withConfig({
  displayName: "Switch__SwitchContainer",
  componentId: "sc-3ijad1-1"
})(["position:relative;display:inline-block;fontsize:16px;line-height:1.5;&:hover > ", ":checked:not(:disabled){background-color:", ";opacity:", ";}&:hover > ", ":not(:checked):not(:disabled){background-color:", ";opacity:", ";z-index:0;}", ":active{transform:scale(0);transition:transform 0s,opacity 0s;}"], SwitchInput, props => props.theme.switch.background, _defaultTheme.opacities.light24, SwitchInput, _defaultTheme.colors.heavyGrey, _defaultTheme.opacities.light38, SwitchInput);

const Slider = _styledComponents.default.span.withConfig({
  displayName: "Switch__Slider",
  componentId: "sc-3ijad1-2"
})(["display:inline-block;width:100%;cursor:pointer;&::before{content:'';display:inline-block;margin:5px 0 5px 10px;border-radius:7px;width:36px;height:14px;background-color:", ";opacity:1;vertical-align:top;transition:background-color 0.2s,opacity 0.2s;}&::after{content:'';position:absolute;top:2px;right:16px;border-radius:50%;width:20px;height:20px;background-color:", ";box-shadow:0 3px 1px -2px rgba(0,0,0,0.2),0 2px 2px 0 rgba(0,0,0,0.14),0 1px 5px 0 rgba(0,0,0,0.12);transition:background-color 0.2s,opacity 0.2s,transform 0.2s;}", ":checked + &::before{background-color:", ";opacity:", ";}", ":checked + &::after{background-color:", ";opacity:1;transform:translateX(16px);}"], _defaultTheme.colors.lightestGrey, props => props.disabled ? _defaultTheme.colors.lightGrey : _defaultTheme.colors.white, SwitchInput, props => props.disabled ? _defaultTheme.colors.lightGrey : props.theme.switch.background, _defaultTheme.opacities.light38, SwitchInput, props => props.disabled ? _defaultTheme.colors.lightGrey : props.theme.switch.background);

const Switch = (_ref) => {
  let _ref$disabled = _ref.disabled,
      disabled = _ref$disabled === void 0 ? false : _ref$disabled,
      _ref$checked = _ref.checked,
      checked = _ref$checked === void 0 ? false : _ref$checked,
      _ref$name = _ref.name,
      name = _ref$name === void 0 ? 'switch' : _ref$name,
      _ref$onChange = _ref.onChange,
      onChange = _ref$onChange === void 0 ? () => {} : _ref$onChange,
      props = _objectWithoutProperties(_ref, ["disabled", "checked", "name", "onChange"]);

  return _react.default.createElement(SwitchContainer, null, _react.default.createElement(SwitchInput, _extends({}, props, {
    type: "checkbox",
    disabled: disabled,
    onChange: onChange,
    defaultChecked: checked,
    "aria-label": name,
    "aria-checked": checked
  })), _react.default.createElement(Slider, {
    disabled: disabled
  }));
};

var _default = Switch;
exports.default = _default;