"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _react = _interopRequireDefault(require("react"));

var _reactFontawesome = require("@fortawesome/react-fontawesome");

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const ChipBase = _styledComponents.default.div.withConfig({
  displayName: "Chip__ChipBase",
  componentId: "sc-1cg0l4b-0"
})(["background-color:", ";box-sizing:border-box;position:relative;display:flex;align-items:center;justify-content:flex-start;cursor:", ";border:1px solid ", "50;box-shadow:1px 1px ", ";overflow:hidden;border-radius:9999px;width:120px;height:32px;font-size:", "px;font-family:Open Sans;color:", ";padding:0px 8px;user-select:none;&:hover{", "}&:after{", "}&:active:after{transform:scale(0,0);opacity:0.1;transition:0s;}", ""], props => !props.disabled ? _defaultTheme.colors.white : _defaultTheme.colors.lightGrey, props => !props.disabled ? 'pointer' : 'not-allowed', props => !props.disabled ? _defaultTheme.colors.lightGrey : _defaultTheme.colors.mediumGrey, props => !props.disabled ? _defaultTheme.colors.lightGrey : _defaultTheme.colors.mediumGrey, _defaultTheme.fontSizes.small, props => props.disabled ? _defaultTheme.colors.mediumGrey : props.theme.chip.text, props => !props.disabled ? "background-color: ".concat(props.theme.chip.hover, ";") : '', props => props.disabled ? '' : "\n    content: '';\n    display: block;\n    position: absolute;\n    width: 100%;\n    height: 100%;\n    top: 0;\n    left: 0;\n    pointer-events: none;\n    background-image: radial-gradient(\n      circle,\n      ".concat(props.theme.chip.text, " 10%,\n      transparent 1%\n    );\n    background-repeat: no-repeat;\n    background-position: 50%;\n    transform: scale(10, 10);\n    opacity: 0;\n    transition: transform 0.5s, opacity 1s;\n    "), props => props.css);

var _StyledChipBase = (0, _styledComponents.default)(ChipBase).withConfig({
  displayName: "Chip___StyledChipBase",
  componentId: "sc-1cg0l4b-1"
})(["", ""], p => p._css);

const Text = _styledComponents.default.p.withConfig({
  displayName: "Chip__Text",
  componentId: "sc-1cg0l4b-2"
})(["padding:inherit;"]);

const Icon = (0, _styledComponents.default)(_reactFontawesome.FontAwesomeIcon).withConfig({
  displayName: "Chip__Icon",
  componentId: "sc-1cg0l4b-3"
})(["icon:", ";alt:", ";padding:inherit;"], props => props.icon, props => props.alt);

const Chip = ({
  icon,
  alt,
  iconLeft,
  disabled,
  onClick,
  css,
  children,
  className
}) => {
  return _react.default.createElement(_StyledChipBase, {
    disabled: disabled,
    onClick: !disabled ? onClick : () => null,
    className: className,
    _css: css
  }, icon && iconLeft && _react.default.createElement(Icon, {
    icon: icon,
    alt: alt
  }), _react.default.createElement(Text, null, children), icon && !iconLeft && _react.default.createElement(Icon, {
    icon: icon,
    alt: alt
  }));
};

var _default = Chip;
exports.default = _default;