"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../../defaultTheme");

var _Body = _interopRequireDefault(require("../../typography/Body"));

var _Check = _interopRequireDefault(require("../../icons/Check"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const Container = _styledComponents.default.label.withConfig({
  displayName: "Checkbox__Container",
  componentId: "jdl6o9-0"
})(["display:flex;align-items:center;justify-content:center;"]);

const CheckboxContainer = _styledComponents.default.div.withConfig({
  displayName: "Checkbox__CheckboxContainer",
  componentId: "jdl6o9-1"
})(["display:inline-block;vertical-align:middle;", ""], props => props.isLabelOnLeft ? 'margin-left: 12px;' : 'margin-right: 12px;');

const CheckboxIcon = (0, _styledComponents.default)(_Check.default).withConfig({
  displayName: "Checkbox__CheckboxIcon",
  componentId: "jdl6o9-2"
})(["display:inline-block;"]); // Hide checkbox visually but remain accessible to screen readers.
// Source: https://polished.js.org/docs/#hidevisually

const HiddenCheckbox = _styledComponents.default.input.withConfig({
  displayName: "Checkbox__HiddenCheckbox",
  componentId: "jdl6o9-3"
})(["border:0;clip:rect(0 0 0 0);clippath:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;white-space:nowrap;width:1px;"]);

const StyledCheckbox = _styledComponents.default.div.withConfig({
  displayName: "Checkbox__StyledCheckbox",
  componentId: "jdl6o9-4"
})(["display:flex;align-items:center;justify-content:center;height:16px;width:16px;border:2px solid ", ";border-radius:2px;transition:all 150ms;", "{visibility:", ";}", ":checked + &{background:", ";border:2px solid ", ";}", ":disabled + &{", ";opacity:", ";}", ":focus:not (:disabled) + &{&::before{content:'';position:absolute;display:block;z-index:-1;width:16px;height:16px;opacity:0.25;border-radius:50%;background-color:", ";}}"], _defaultTheme.colors.mediumGrey, CheckboxIcon, props => props.isChecked ? 'visible' : 'hidden', HiddenCheckbox, props => props.theme.checkbox.background, props => props.theme.checkbox.border, HiddenCheckbox, props => props.isChecked && 'background-color: #000', _defaultTheme.opacities.light38, HiddenCheckbox, _defaultTheme.colors.heavyGrey);

const Checkbox = (_ref) => {
  let _ref$children = _ref.children,
      children = _ref$children === void 0 ? '' : _ref$children,
      _ref$isLabelOnLeft = _ref.isLabelOnLeft,
      isLabelOnLeft = _ref$isLabelOnLeft === void 0 ? false : _ref$isLabelOnLeft,
      _ref$isChecked = _ref.isChecked,
      isChecked = _ref$isChecked === void 0 ? false : _ref$isChecked,
      styles = _ref.styles,
      _ref$isDisabled = _ref.isDisabled,
      isDisabled = _ref$isDisabled === void 0 ? false : _ref$isDisabled,
      onChange = _ref.onChange,
      className = _ref.className,
      _ref$icon = _ref.icon,
      icon = _ref$icon === void 0 ? _react.default.createElement(CheckboxIcon, {
    height: "14",
    width: "14",
    color: _defaultTheme.colors.white
  }) : _ref$icon,
      props = _objectWithoutProperties(_ref, ["children", "isLabelOnLeft", "isChecked", "styles", "isDisabled", "onChange", "className", "icon"]);

  return _react.default.createElement(Container, {
    className: className
  }, isLabelOnLeft && children && _react.default.createElement(_Body.default, null, children), _react.default.createElement(CheckboxContainer, {
    isLabelOnLeft: isLabelOnLeft
  }, _react.default.createElement(HiddenCheckbox, _extends({}, props, {
    onChange: onChange,
    checked: isChecked,
    disabled: isDisabled,
    type: "checkbox"
  })), _react.default.createElement(StyledCheckbox, {
    isChecked: isChecked
  }, icon)), !isLabelOnLeft && children && _react.default.createElement(_Body.default, null, children));
};

var _default = Checkbox;
exports.default = _default;