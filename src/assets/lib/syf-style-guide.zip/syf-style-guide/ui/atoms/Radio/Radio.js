"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _react = _interopRequireDefault(require("react"));

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const Container = _styledComponents.default.div.withConfig({
  displayName: "Radio__Container",
  componentId: "sc-365oiw-0"
})(["margin:0.5rem 0;"]);

const RadioInput = _styledComponents.default.input.withConfig({
  displayName: "Radio__RadioInput",
  componentId: "sc-365oiw-1"
})(["appearance:none;z-index:-1;position:absolute;display:block;border-radius:50%;width:40px;height:40px;outline:none;opacity:0;background-color:transparent;pointer-events:none;display:none;&:checked{transform:translateX(16px);}&:focus:checked{background-color:", ";opacity:", ";margin-left:-61px;margin-top:-10px;}&:focus:not(:checked){background-color:", ";opacity:", ";z-index:0;margin-left:-45px;margin-top:-10px;}"], _defaultTheme.colors.heavyGrey, _defaultTheme.opacities.light24, _defaultTheme.colors.heavyGrey, _defaultTheme.opacities.light24);

const Label = _styledComponents.default.label.withConfig({
  displayName: "Radio__Label",
  componentId: "sc-365oiw-2"
})(["position:relative;display:inline-block;left:", ";cursor:pointer;", " ", ":disabled + &{::before{border:2px solid ", ";}}", ":checked:disabled + &{::after{background:", ";}}", ":checked:not(:disabled) ~ &{::before{border:2px solid ", ";}::after{background:", ";}}&::before{content:'';display:inline-block;", " border-radius:50%;border:2px solid ", ";width:16px;height:16px;}&::after{content:'';position:absolute;display:inline-block;", " border-radius:50%;width:10px;height:10px;}"], props => props.direction === 'row' ? '5px' : '35px', props => props.direction === 'row' && 'margin-right: 15px;', RadioInput, _defaultTheme.colors.mediumGrey, RadioInput, _defaultTheme.colors.mediumGrey, RadioInput, props => props.theme.radio.border, props => props.theme.radio.background, props => props.direction === 'row' ? "position: relative;\n           top: 4px;\n           right: 3px;" : "position: absolute;\n           left: -35px;", _defaultTheme.colors.mediumGrey, props => props.direction === 'row' ? "left: 2px;\n           top: 9px;" : "left: -30px;\n           top: 5px;");

const Radio = (_ref) => {
  let _ref$name = _ref.name,
      name = _ref$name === void 0 ? 'radiobutton-name' : _ref$name,
      _ref$id = _ref.id,
      id = _ref$id === void 0 ? 'radiobutton-id' : _ref$id,
      value = _ref.value,
      _ref$children = _ref.children,
      children = _ref$children === void 0 ? '' : _ref$children,
      _ref$disabled = _ref.disabled,
      disabled = _ref$disabled === void 0 ? false : _ref$disabled,
      _ref$onChange = _ref.onChange,
      onChange = _ref$onChange === void 0 ? () => {} : _ref$onChange,
      size = _ref.size,
      _ref$checked = _ref.checked,
      checked = _ref$checked === void 0 ? false : _ref$checked,
      styles = _ref.styles,
      direction = _ref.direction,
      className = _ref.className,
      props = _objectWithoutProperties(_ref, ["name", "id", "value", "children", "disabled", "onChange", "size", "checked", "styles", "direction", "className"]);

  return _react.default.createElement(Container, {
    className: className
  }, _react.default.createElement(RadioInput, _extends({}, props, {
    id: id,
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    onChange: onChange,
    disabled: disabled
  })), _react.default.createElement(Label, {
    htmlFor: id,
    direction: direction
  }, children));
};

var _default = Radio;
exports.default = _default;