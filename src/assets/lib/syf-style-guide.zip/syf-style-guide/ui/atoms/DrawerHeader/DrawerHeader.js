"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _react = _interopRequireDefault(require("react"));

var _defaultTheme = require("../../../defaultTheme");

var _typography = require("../../typography");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const DrawerHeaderBase = _styledComponents.default.div.withConfig({
  displayName: "DrawerHeader__DrawerHeaderBase",
  componentId: "sc-1cti0lx-0"
})(["display:flex;flex-direction:row;"]);

const Column = _styledComponents.default.div.withConfig({
  displayName: "DrawerHeader__Column",
  componentId: "sc-1cti0lx-1"
})(["display:flex;flex-direction:column;justify-content:center;padding:5px;", ""], props => props.second ? 'padding-left: 16px;' : "\n      width: 88px;\n      border-radius: 3px;\n      border: 1px solid ".concat(_defaultTheme.colors.lightGrey, ";\n    "));

const Image = _styledComponents.default.img.withConfig({
  displayName: "DrawerHeader__Image",
  componentId: "sc-1cti0lx-2"
})(["width:100%;height:100%;"]);

var _StyledBody = (0, _styledComponents.default)(_typography.Body).withConfig({
  displayName: "DrawerHeader___StyledBody",
  componentId: "sc-1cti0lx-3"
})(["font-size:", "px;"], p => p._css);

const DrawerHeader = ({
  img,
  title,
  subtitle,
  alt,
  className
}) => {
  return _react.default.createElement(DrawerHeaderBase, {
    className: className
  }, img && _react.default.createElement(Column, null, _react.default.createElement(Image, {
    "data-test": "image",
    src: img,
    alt: alt
  })), _react.default.createElement(Column, {
    second: true
  }, _react.default.createElement(_StyledBody, {
    _css: _defaultTheme.fontSizes.medium
  }, title), _react.default.createElement("div", {
    "data-test": "subtitle"
  }, typeof subtitle === 'string' ? _react.default.createElement(_typography.Small, null, subtitle) : subtitle)));
};

var _default = DrawerHeader;
exports.default = _default;