"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _Small = _interopRequireDefault(require("../../typography/Small"));

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const Container = _styledComponents.default.div.withConfig({
  displayName: "Textfield__Container",
  componentId: "sc-1e9iie3-0"
})(["width:275px;color:", ";text-align:left;input[type='number']::-webkit-inner-spin-button,input[type='number']::-webkit-outer-spin-button{-webkit-appearance:none;-moz-appearance:none;appearance:none;margin:0;}"], props => props.hasError ? _defaultTheme.colors.error : _defaultTheme.colors.mediumGrey);

const Input = _styledComponents.default.input.withConfig({
  displayName: "Textfield__Input",
  componentId: "sc-1e9iie3-1"
})(["position:relative;font-size:", "px;height:100%;top:5px;left:", ";width:", " border:none;background:none;cursor:", ";color:", ";padding:0;&:focus{outline:none;color:", ";}&:hover:{border:none;outline:none;}"], _defaultTheme.fontSizes.root, props => props.hasIcon ? '16px' : '0', props => {
  if (props.showMaskedOption && props.hasIcon) return '64%;';
  if (props.showMaskedOption) return '73%;';
  if (props.hasIcon) return '90%;';
  return '100%;';
}, props => props.disabled ? 'not-allowed' : 'text', props => props.hasContent && !props.disabled ? _defaultTheme.colors.black : 'inherit', _defaultTheme.colors.black);

const Label = _styledComponents.default.label.withConfig({
  displayName: "Textfield__Label",
  componentId: "sc-1e9iie3-2"
})(["position:absolute;font-size:inherit;font-family:Open Sans;left:", ";top:calc(50% - 0.7em);transition-property:left,top,font-size;transition-duration:0.1s;color:", ";cursor:", ";text-indent:0;", " ", ":focus ~ &{font-size:", "px;top:5px;}"], props => props.hasIcon ? '48px' : '16px', props => props.hasError ? _defaultTheme.colors.error : _defaultTheme.colors.mediumGrey, props => props.isDisabled ? 'not-allowed' : 'text', props => props.defaultFixedLabel ? "\n      font-size: ".concat(_defaultTheme.fontSizes.small, "px;\n      top: 5px;\n    ") : '', Input, _defaultTheme.fontSizes.small);

const HelpTextWrapper = _styledComponents.default.div.withConfig({
  displayName: "Textfield__HelpTextWrapper",
  componentId: "sc-1e9iie3-3"
})(["display:flex;margin-top:4px;color:inherit;align-items:center;"]);

const HelpText = (0, _styledComponents.default)(_Small.default).withConfig({
  displayName: "Textfield__HelpText",
  componentId: "sc-1e9iie3-4"
})(["display:block;padding:0;margin:0;flex-basis:100%;color:", ";"], props => props.error ? _defaultTheme.colors.error : _defaultTheme.colors.black);

const InputWrapper = _styledComponents.default.div.withConfig({
  displayName: "Textfield__InputWrapper",
  componentId: "sc-1e9iie3-5"
})(["color:", ";width:", ";height:24px;padding:", ";position:relative;border-radius:6px;box-shadow:0 0 0 ", " display:flex;align-items:center;&:hover{", "}cursor:", ";background-color:", ";&:focus-within{box-shadow:0 0 0 2px ", ";}"], props => props.hasError ? _defaultTheme.colors.error : _defaultTheme.colors.mediumGrey, props => props.width, props => props.leftIcon ? '12px' : '12px 16px', props => {
  if (props.isDisabled) return "1px ".concat(_defaultTheme.colors.grey, ";");
  if (props.hasError) return "2px ".concat(_defaultTheme.colors.error, ";");
  return "1px ".concat(_defaultTheme.colors.heavyGrey, ";");
}, props => props.hasError || props.isDisabled ? '' : "box-shadow: 0 0 0 2px ".concat(_defaultTheme.colors.heavyGrey, ";"), props => props.isDisabled ? 'not-allowed' : 'text', props => props.isDisabled ? _defaultTheme.colors.lightestGrey : '', props => props.hasError ? _defaultTheme.colors.error : props.theme.field.focus);

const ShowHideWrapper = _styledComponents.default.div.withConfig({
  displayName: "Textfield__ShowHideWrapper",
  componentId: "sc-1e9iie3-6"
})(["position:absolute;right:16px;display:flex;align-items:center;justify-content:center;min-width:22%;font-weight:", ";color:", ";> span{user-select:none;cursor:pointer;border:none;background:none;&:focus{outline:", " auto 5px;}}"], _defaultTheme.fontWeights.light, props => props.hasError ? _defaultTheme.colors.error : props.theme.link, props => props.theme.field.focus || '-webkit-focus-ring-color');

const LeftIconWrapper = _styledComponents.default.div.withConfig({
  displayName: "Textfield__LeftIconWrapper",
  componentId: "sc-1e9iie3-7"
})(["height:100%;display:flex;justify-content:center;align-items:center;color:", ";"], props => props.hasError ? _defaultTheme.colors.error : props.theme.field.icon);

const ErrorIconWrapper = _styledComponents.default.div.withConfig({
  displayName: "Textfield__ErrorIconWrapper",
  componentId: "sc-1e9iie3-8"
})(["height:100%;margin-right:4px;display:flex;justify-content:center;align-items:center;"]);

const Textfield = (_ref) => {
  let _ref$type = _ref.type,
      type = _ref$type === void 0 ? 'text' : _ref$type,
      _ref$autoCapitalize = _ref.autoCapitalize,
      autoCapitalize = _ref$autoCapitalize === void 0 ? 'none' : _ref$autoCapitalize,
      _ref$placeholder = _ref.placeholder,
      placeholder = _ref$placeholder === void 0 ? '' : _ref$placeholder,
      _ref$isDisabled = _ref.isDisabled,
      isDisabled = _ref$isDisabled === void 0 ? false : _ref$isDisabled,
      _ref$helpText = _ref.helpText,
      helpText = _ref$helpText === void 0 ? '' : _ref$helpText,
      _ref$leftIcon = _ref.leftIcon,
      leftIcon = _ref$leftIcon === void 0 ? null : _ref$leftIcon,
      _ref$errorIcon = _ref.errorIcon,
      errorIcon = _ref$errorIcon === void 0 ? null : _ref$errorIcon,
      _ref$error = _ref.error,
      error = _ref$error === void 0 ? '' : _ref$error,
      _ref$name = _ref.name,
      name = _ref$name === void 0 ? 'syf-text-field' : _ref$name,
      _ref$id = _ref.id,
      id = _ref$id === void 0 ? 'syf-text-field' : _ref$id,
      matchPattern = _ref.matchPattern,
      _ref$value = _ref.value,
      value = _ref$value === void 0 ? '' : _ref$value,
      _ref$showMaskedOption = _ref.showMaskedOption,
      showMaskedOption = _ref$showMaskedOption === void 0 ? false : _ref$showMaskedOption,
      _ref$showTextValue = _ref.showTextValue,
      showTextValue = _ref$showTextValue === void 0 ? 'Show' : _ref$showTextValue,
      _ref$hideTextValue = _ref.hideTextValue,
      hideTextValue = _ref$hideTextValue === void 0 ? 'Hide' : _ref$hideTextValue,
      onChange = _ref.onChange,
      className = _ref.className,
      onBlur = _ref.onBlur,
      props = _objectWithoutProperties(_ref, ["type", "autoCapitalize", "placeholder", "isDisabled", "helpText", "leftIcon", "errorIcon", "error", "name", "id", "matchPattern", "value", "showMaskedOption", "showTextValue", "hideTextValue", "onChange", "className", "onBlur"]);

  const inputRef = _react.default.useRef(null);

  const _useState = (0, _react.useState)(type),
        _useState2 = _slicedToArray(_useState, 2),
        typeValue = _useState2[0],
        setTypeValue = _useState2[1];

  const hasContent = value.length > 0;
  const defaultFixedLabel = hasContent && error || hasContent && isDisabled || hasContent;

  const clickFocus = () => inputRef.current && inputRef.current.focus();

  const handleMatchRegex = event => {
    if (!matchPattern) return;
    const pattern = new RegExp(matchPattern);
    const keyCode = event.keyCode || event.which;
    const keyValue = String.fromCharCode(keyCode);
    if (matchPattern && pattern.test(keyValue)) event.preventDefault();
  };

  const handleShowHideKeyDown = e => {
    if (e.keyCode === 9 || e.shiftKey && e.keyCode === 9) return;
    if (e.shiftKey) e.preventDefault();

    if (e.keyCode === 13) {
      e.preventDefault();
      setTypeValue(typeValue === 'password' ? 'text' : 'password');
      clickFocus();
    }
  };

  const handleShowHideMouseDown = e => {
    e.stopPropagation();
    e.preventDefault();
    clickFocus();
  };

  const handleShowHideMouseUp = () => {
    setTypeValue(typeValue === 'password' ? 'text' : 'password');
  };

  return _react.default.createElement(Container, {
    hasError: error,
    className: className
  }, _react.default.createElement(InputWrapper, {
    hasError: error,
    onClick: clickFocus,
    isDisabled: isDisabled,
    "data-test": "text-field-wrapper"
  }, leftIcon && _react.default.createElement(LeftIconWrapper, {
    hasError: error
  }, leftIcon), _react.default.createElement(Input, _extends({
    id: id,
    autoCapitalize: autoCapitalize,
    name: name,
    type: typeValue,
    ref: inputRef,
    hasIcon: !!leftIcon,
    onKeyPress: handleMatchRegex,
    disabled: isDisabled,
    hasContent: hasContent,
    value: value,
    onChange: onChange,
    showMaskedOption: showMaskedOption,
    onBlur: onBlur
  }, props)), _react.default.createElement(Label, {
    htmlFor: id,
    defaultFixedLabel: defaultFixedLabel,
    hasError: error,
    isDisabled: isDisabled,
    "data-test": "text-field-label",
    hasIcon: !!leftIcon,
    hasContent: hasContent
  }, placeholder), showMaskedOption && _react.default.createElement(ShowHideWrapper, {
    hasError: error
  }, _react.default.createElement("span", {
    id: "showhide",
    tabIndex: "0",
    onKeyDown: handleShowHideKeyDown,
    onMouseDown: handleShowHideMouseDown,
    onMouseUp: handleShowHideMouseUp,
    role: "button"
  }, typeValue === 'password' ? showTextValue : hideTextValue))), _react.default.createElement(HelpTextWrapper, null, errorIcon && error && _react.default.createElement(ErrorIconWrapper, null, errorIcon), _react.default.createElement(HelpText, {
    id: "syf-help-text-".concat(name),
    error: error
  }, error || helpText)));
};

var _default = Textfield;
exports.default = _default;