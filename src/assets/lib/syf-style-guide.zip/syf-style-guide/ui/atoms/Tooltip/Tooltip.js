"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _reactLaag = require("react-laag");

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const TooltipContainer = _styledComponents.default.div.withConfig({
  displayName: "Tooltip__TooltipContainer",
  componentId: "sc-1iq9s6t-0"
})(["", " padding:12px;min-width:200px;max-width:300px;width:", "px;min-height:50px;height:", "px;background-color:", ";border:", ";color:inherit;font-size:inherit;line-height:inherit;box-shadow:2px 4px 8px ", ";margin-top:0;border-radius:6px;"], props => props.layerProps.style, props => props.width, props => props.height, props => props.backgroundColor, props => "".concat(props.borderWidth, "px solid ").concat(props.borderColor), _defaultTheme.colors.lightGrey);

const TootltipButton = _styledComponents.default.button.withConfig({
  displayName: "Tooltip__TootltipButton",
  componentId: "sc-1iq9s6t-1"
})(["margin:4px;border:none;background-color:", ";color:white;cursor:pointer;border-radius:50%;border:none;"], props => props.triggerColor);

const Tooltip = ({
  backgroundColor = _defaultTheme.colors.lightBlue,
  borderColor = _defaultTheme.colors.grey,
  triggerColor = _defaultTheme.colors.mediumGrey,
  hasBorder = true,
  autoAdjust = true,
  content,
  placement,
  width,
  height,
  className
}) => {
  return React.createElement(_reactLaag.ToggleLayer, {
    closeOnOutsideClick: true,
    fixed: true,
    placement: {
      anchor: placement,
      autoAdjust,
      triggerOffset: 10
    },
    renderLayer: ({
      isOpen,
      layerProps,
      arrowStyle,
      layerSide
    }) => isOpen && React.createElement(TooltipContainer, {
      className: className,
      ref: layerProps.ref,
      borderWidth: hasBorder ? 1 : 0,
      layerProps: layerProps,
      borderColor: borderColor,
      backgroundColor: backgroundColor,
      width: width,
      height: height
    }, content, React.createElement(_reactLaag.Arrow, {
      style: arrowStyle,
      layerSide: layerSide,
      backgroundColor: backgroundColor,
      borderWidth: hasBorder ? 1 : 0,
      borderColor: borderColor,
      roundness: 0.5
    }))
  }, ({
    triggerRef,
    toggle
  }) => React.createElement(TootltipButton, {
    type: "button",
    ref: triggerRef,
    onClick: toggle,
    triggerColor: triggerColor
  }, "?"));
};

var _default = Tooltip;
exports.default = _default;