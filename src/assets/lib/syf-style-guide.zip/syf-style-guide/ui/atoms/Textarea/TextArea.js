"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _react = _interopRequireDefault(require("react"));

var _reactFontawesome = require("@fortawesome/react-fontawesome");

var _Small = _interopRequireDefault(require("../../typography/Small"));

var _Body = _interopRequireDefault(require("../../typography/Body"));

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const Input = _styledComponents.default.textarea.withConfig({
  displayName: "TextArea__Input",
  componentId: "sc-1y349jb-0"
})(["max-width:80vw;padding:8px;font-size:14px;color:", ";width:", ";height:", ";position:relative;border-radius:5px;box-shadow:0 0 0 ", " display:flex;align-items:center;flex-wrap:wrap;&:hover{", " cursor:text;}background-color:", ";&:focus-within{box-shadow:0 0 0 2px ", ";color:", ";}font-family:Open Sans;", ""], props => props.hasError ? _defaultTheme.colors.error : _defaultTheme.colors.mediumGrey, props => props.width, props => "calc(".concat(props.width, " / ").concat(props.ratio, ")"), props => props.hasError ? "2px ".concat(_defaultTheme.colors.error, ";") : "1px ".concat(_defaultTheme.colors.heavyGrey, ";"), props => props.hasError || props.disabled ? '' : "box-shadow: 0 0 0 2px ".concat(_defaultTheme.colors.heavyGrey, ";"), props => props.disabled ? _defaultTheme.colors.lightestGrey : '', _defaultTheme.colors.mediumGrey, _defaultTheme.colors.heavyGrey, props => props.css);

var _StyledInput = (0, _styledComponents.default)(Input).withConfig({
  displayName: "TextArea___StyledInput",
  componentId: "sc-1y349jb-1"
})(["", ""], p => p._css4);

const Label = _styledComponents.default.label.withConfig({
  displayName: "TextArea__Label",
  componentId: "sc-1y349jb-2"
})(["width:100%;min-height:100px;font-size:1.2em;font-family:Open Sans;color:", ";", ""], props => props.hasError ? _defaultTheme.colors.error : 'inherit', props => props.css);

var _StyledLabel = (0, _styledComponents.default)(Label).withConfig({
  displayName: "TextArea___StyledLabel",
  componentId: "sc-1y349jb-3"
})(["", ""], p => p._css);

const IconWrapper = _styledComponents.default.div.withConfig({
  displayName: "TextArea__IconWrapper",
  componentId: "sc-1y349jb-4"
})(["display:flex;padding-bottom:5px;align-items:center;", ""], props => props.css);

var _StyledIconWrapper = (0, _styledComponents.default)(IconWrapper).withConfig({
  displayName: "TextArea___StyledIconWrapper",
  componentId: "sc-1y349jb-5"
})(["", ""], p => p._css3);

const ErrorIcon = (0, _styledComponents.default)(_reactFontawesome.FontAwesomeIcon).withConfig({
  displayName: "TextArea__ErrorIcon",
  componentId: "sc-1y349jb-6"
})(["padding-left:0;", ":focus ~ &{display:none;}"], Input);

var _StyledBody = (0, _styledComponents.default)(_Body.default).withConfig({
  displayName: "TextArea___StyledBody",
  componentId: "sc-1y349jb-7"
})(["", ""], p => p._css2);

var _StyledSmall = (0, _styledComponents.default)(_Small.default).withConfig({
  displayName: "TextArea___StyledSmall",
  componentId: "sc-1y349jb-8"
})(["margin-left:5px;"]);

const Textarea = (_ref) => {
  let errorIcon = _ref.errorIcon,
      _ref$autoCapitalize = _ref.autoCapitalize,
      autoCapitalize = _ref$autoCapitalize === void 0 ? 'none' : _ref$autoCapitalize,
      disabled = _ref.disabled,
      _ref$width = _ref.width,
      width = _ref$width === void 0 ? '400px' : _ref$width,
      _ref$sizeRatio = _ref.sizeRatio,
      sizeRatio = _ref$sizeRatio === void 0 ? 5 : _ref$sizeRatio,
      _ref$label = _ref.label,
      label = _ref$label === void 0 ? '' : _ref$label,
      _ref$error = _ref.error,
      error = _ref$error === void 0 ? '' : _ref$error,
      styles = _ref.styles,
      _ref$name = _ref.name,
      name = _ref$name === void 0 ? 'syf-text-area-name' : _ref$name,
      _ref$id = _ref.id,
      id = _ref$id === void 0 ? 'syf-text-area-id' : _ref$id,
      value = _ref.value,
      props = _objectWithoutProperties(_ref, ["errorIcon", "autoCapitalize", "disabled", "width", "sizeRatio", "label", "error", "styles", "name", "id", "value"]);

  return _react.default.createElement(_StyledLabel, {
    htmlFor: id,
    hasError: error,
    _css: styles && styles.root
  }, _react.default.createElement(_StyledBody, {
    _css2: styles && styles.label
  }, label), _react.default.createElement(_StyledIconWrapper, {
    _css3: styles && styles.errorIconWrapper
  }, error && errorIcon && _react.default.createElement(ErrorIcon, {
    size: "1x",
    icon: errorIcon,
    alt: "Error Icon"
  }), _react.default.createElement(_StyledSmall, null, error)), _react.default.createElement(_StyledInput, _extends({}, props, {
    id: id,
    name: name,
    width: width,
    ratio: sizeRatio,
    hasError: error,
    disabled: disabled,
    autoCapitalize: autoCapitalize,
    "data-test": "text-area-wrapper",
    value: value,
    _css4: styles && styles.input
  })));
};

var _default = Textarea;
exports.default = _default;