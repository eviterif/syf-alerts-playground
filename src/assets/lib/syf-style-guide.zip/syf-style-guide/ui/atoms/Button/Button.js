"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const getSharedStyles = () => "\n  height: 48px;\n  border-style: solid;\n  border-color: transparent;\n  border-radius: 6px;\n  border-width: 2px;\n  padding: 0 16px;\n  text-transform: uppercase;\n";

const getHoverStyles = (props, role) => "\n  &:hover {\n    ".concat(!props.disabled ? "background-color: ".concat(props.theme.button[role].hover, ";") : '', "\n  }\n");

const getActiveStyles = (props, role) => {
  if (!props.disabled) {
    return "\n      &:after {\n        content: '';\n        display: block;\n        position: absolute;\n        width: 100%;\n        height: 100%;\n        top: 0;\n        left: 0;\n        pointer-events: none;\n        background-image: radial-gradient(\n          circle,\n          ".concat(role !== 'primary' ? props.theme.button.background : _defaultTheme.colors.white, " 10%,\n          transparent 10.01%\n        );\n        background-repeat: no-repeat;\n        background-position: 50%;\n        transform: scale(10, 10);\n        opacity: 0;\n        transition: transform 0.5s, opacity 1s;\n      }\n      &:active:after {\n        transform: scale(0, 0);\n        opacity: 0.3;\n        transition: 0s;\n      }\n  ");
  }

  return '';
};

const StyledButton = _styledComponents.default.button.withConfig({
  displayName: "Button__StyledButton",
  componentId: "sc-13kyyco-0"
})(["position:relative;font-family:Open Sans;font-size:", "px;min-width:120px;display:flex;flex-direction:row;justify-content:center;align-items:center;cursor:", ";color:", ";overflow:hidden;font-weight:700;margin:8px;", ""], _defaultTheme.fontSizes.root, props => props.disabled ? 'not-allowed' : 'pointer', props => props.disabled ? _defaultTheme.colors.mediumGrey : props.theme.button.background, props => {
  if (props.buttonType === 'primary') {
    return "\n        background-color: ".concat(props.disabled ? _defaultTheme.colors.lightGrey : props.theme.button.background, ";\n        border: none;\n        color: ").concat(_defaultTheme.colors.white, ";\n        ").concat(getSharedStyles(), "\n        ").concat(getActiveStyles(props, 'primary'), "\n        ").concat(getHoverStyles(props, 'primary'), "\n      ");
  }

  if (props.buttonType === 'secondary' || props.buttonType === 'ghost') {
    return "\n        ".concat(getSharedStyles(), "\n        ").concat(getActiveStyles(props, 'secondary'), "\n        ").concat(getHoverStyles(props, 'secondary'), "\n        ").concat(props.buttonType === 'ghost' ? 'background: inherit;' : "border-color: ".concat(props.disabled ? _defaultTheme.colors.mediumGrey : props.theme.button.background, ";"), "\n      ");
  }

  if (props.buttonType === 'text') {
    return "\n        background: inherit;\n        height: 24px;\n        border: none;\n        padding: 0 8px;\n        min-width: 0;\n\n        &:hover {\n          text-decoration: underline;\n        }\n      ";
  }

  return '';
});

const Button = props => {
  const buttonType = props.buttonType,
        _props$disabled = props.disabled,
        disabled = _props$disabled === void 0 ? false : _props$disabled,
        alt = props.alt,
        children = props.children,
        onClick = props.onClick,
        className = props.className;
  return React.createElement(StyledButton, {
    className: className,
    buttonType: buttonType,
    disabled: disabled,
    alt: alt,
    onClick: onClick
  }, children);
};

var _default = Button;
exports.default = _default;