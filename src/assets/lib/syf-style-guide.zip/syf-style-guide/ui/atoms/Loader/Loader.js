"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _Spinner = _interopRequireDefault(require("../../icons/Spinner"));

var _defaultTheme = require("../../../defaultTheme");

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const SpinnerAnimation = (0, _styledComponents.keyframes)(["0%{transform:rotate(0);}100%{transform:rotate(360deg);}"]);

const LoadingWrapper = _styledComponents.default.div.withConfig({
  displayName: "Loader__LoadingWrapper",
  componentId: "sc-1scr1l9-0"
})(["svg,png,jpg{animation:", " 1s ease-out infinite;}"], SpinnerAnimation);

const Loader = (_ref) => {
  let height = _ref.height,
      width = _ref.width,
      _ref$color = _ref.color,
      color = _ref$color === void 0 ? _defaultTheme.colors.grey : _ref$color,
      _ref$icon = _ref.icon,
      icon = _ref$icon === void 0 ? _react.default.createElement(_Spinner.default, {
    height: height,
    width: width,
    color: color
  }) : _ref$icon,
      className = _ref.className,
      props = _objectWithoutProperties(_ref, ["height", "width", "color", "icon", "className"]);

  return _react.default.createElement(LoadingWrapper, _extends({
    className: className
  }, props), icon);
};

var _default = Loader;
exports.default = _default;