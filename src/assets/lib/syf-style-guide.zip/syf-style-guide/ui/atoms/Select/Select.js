"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _Small = _interopRequireDefault(require("../../typography/Small"));

var _defaultTheme = require("../../../defaultTheme");

var _mediaQueries = _interopRequireDefault(require("../../../mediaQueries"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const FieldWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__FieldWrapper",
  componentId: "sc-10rv94f-0"
})(["width:100%;@media ", "{width:400px;}"], _mediaQueries.default.greaterThanMedium);

const SelectOutterWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__SelectOutterWrapper",
  componentId: "sc-10rv94f-1"
})(["position:relative;box-sizing:border-box;font-family:inherit;"]);

const SelectInnerWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__SelectInnerWrapper",
  componentId: "sc-10rv94f-2"
})(["font-size:inherit;color:", ";width:100%;height:48px;position:relative;border-radius:6px;", " box-shadow:0 0 0 ", " display:flex;border:none;align-items:center;flex-wrap:wrap;&:hover{", " cursor:normal;}background-color:", ";&:focus-within{", "}transition:all 100ms ease 0s;outline:0px !important;justify-content:space-between;cursor:default;"], props => props.error ? _defaultTheme.colors.error : _defaultTheme.colors.mediumGrey, props => props.isMenuOpen && "\n      border-bottom-right-radius: 0;\n      border-bottom-left-radius: 0;\n    ", props => props.error ? "2px ".concat(_defaultTheme.colors.error, ";") : "1px ".concat(_defaultTheme.colors.heavyGrey, ";"), props => props.error || props.isDisabled ? '' : "box-shadow: 0 0 0 2px ".concat(_defaultTheme.colors.heavyGrey, ";"), props => props.isDisabled ? _defaultTheme.colors.lightestGrey : _defaultTheme.colors.white, props => props.isDisabled ? '' : "\n        box-shadow: 0 0 0 2px ".concat(props.theme.field.focus, ";\n        color: ").concat(_defaultTheme.colors.heavyGrey, ";\n      "));

const Label = _styledComponents.default.label.withConfig({
  displayName: "Select__Label",
  componentId: "sc-10rv94f-3"
})(["font-size:", "px;left:", ";padding:0px;opacity:0;left:0;top:4px;transition-property:opacity;transition-duration:0.2s;position:absolute;color:", ";", ""], _defaultTheme.fontSizes.small, props => props.hasIcon ? '48px' : '16px', props => {
  if (props.error && !props.isMenuOpen) return "".concat(_defaultTheme.colors.error, ";");
  if (!props.isDisabled) return "".concat(props.theme.field.label, ";");
  return "".concat(_defaultTheme.colors.mediumGrey, ";");
}, props => props.animateLabel && props.isMenuOpen || props.isSelected ? 'opacity: 1;' : '');

const SelectedPlaceholder = _styledComponents.default.span.withConfig({
  displayName: "Select__SelectedPlaceholder",
  componentId: "sc-10rv94f-4"
})(["position:absolute;left:0;bottom:14px;transition-property:bottom;transition-duration:0.2s;", ""], props => props.animateLabel && props.isMenuOpen || props.isSelected ? 'bottom: 6px;' : '');

const SelectValueWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__SelectValueWrapper",
  componentId: "sc-10rv94f-5"
})(["font-size:inherit;height:100%;display:flex;align-items:center;color:", ";flex-wrap:wrap;position:relative;box-sizing:border-box;flex:1 1 0%;padding:2px 8px;padding-left:", ";overflow:hidden;"], _defaultTheme.colors.mediumGrey, props => props.hasIcon ? '0' : '8px');

const Placeholder = _styledComponents.default.div.withConfig({
  displayName: "Select__Placeholder",
  componentId: "sc-10rv94f-6"
})(["font-family:'Open Sans';font-size:inherit;height:100%;width:100%;display:flex;flex-direction:column;justify-content:center;align-items:flex-start;color:", ";margin-left:2px;margin-right:2px;position:absolute;top:50%;transform:translateY(-50%);box-sizing:border-box;user-select:none;"], _defaultTheme.colors.mediumGrey);

const SelectInputWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__SelectInputWrapper",
  componentId: "sc-10rv94f-7"
})(["padding-bottom:2px;padding-top:2px;visibility:visible;color:", ";box-sizing:border-box;margin:2px;"], _defaultTheme.colors.black);

const SelectInput = _styledComponents.default.div.withConfig({
  displayName: "Select__SelectInput",
  componentId: "sc-10rv94f-8"
})(["box-sizing:content-box;width:2px;background:0px center;border:0px;font-size:inherit;opacity:1;outline:0px;padding:0px;color:inherit;"]);

const RightIconWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__RightIconWrapper",
  componentId: "sc-10rv94f-9"
})(["display:flex;box-sizing:border-box;padding:8px;transition:color 150ms ease 0s;color:", ";"], props => props.error && !props.isMenuOpen ? _defaultTheme.colors.error : _defaultTheme.colors.mediumGrey);

const OptionsMenuWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__OptionsMenuWrapper",
  componentId: "sc-10rv94f-10"
})(["background-color:", ";box-shadow:0 0 0 ", " border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-left-radius:4px;border-bottom-right-radius:4px;position:absolute;z-index:1;box-sizing:border-box;width:100%;margin-top:2px;"], _defaultTheme.colors.white, props => props.error ? "2px ".concat(_defaultTheme.colors.error, ";") : "1px ".concat(_defaultTheme.colors.heavyGrey, ";"));

const OptionsMenuInnerWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__OptionsMenuInnerWrapper",
  componentId: "sc-10rv94f-11"
})(["overflow-y:auto;position:relative;box-sizing:border-box;"]);

const OptionWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__OptionWrapper",
  componentId: "sc-10rv94f-12"
})(["display:flex;align-items:center;background-color:", ";border-bottom:solid 1px ", ";height:48px;font-weight:", ";&:hover{background-color:", ";}"], props => props.selected ? props.theme.field.background : 'transparent', _defaultTheme.colors.heavyGrey, props => props.selected ? 'bold' : 'regular', props => props.theme.field.background);

const Option = _styledComponents.default.div.withConfig({
  displayName: "Select__Option",
  componentId: "sc-10rv94f-13"
})(["color:inherit;cursor:default;display:block;font-size:inherit;width:100%;user-select:none;-webkit-tap-highlight-color:transparent;box-sizing:border-box;padding:8px 12px;"]);

const ErrorIconWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__ErrorIconWrapper",
  componentId: "sc-10rv94f-14"
})(["height:100%;margin-right:5px;display:flex;justify-content:center;align-items:center;"]);

const HelpText = (0, _styledComponents.default)(_Small.default).withConfig({
  displayName: "Select__HelpText",
  componentId: "sc-10rv94f-15"
})(["display:block;padding:5px 0px;flex-basis:100%;color:", ";"], props => props.error ? _defaultTheme.colors.error : _defaultTheme.colors.mediumGrey);

const HelpTextWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__HelpTextWrapper",
  componentId: "sc-10rv94f-16"
})(["display:flex;color:", ";align-items:center;"], props => props.error ? _defaultTheme.colors.error : _defaultTheme.colors.mediumGrey);

const LeftIconWrapper = _styledComponents.default.div.withConfig({
  displayName: "Select__LeftIconWrapper",
  componentId: "sc-10rv94f-17"
})(["min-width:12%;display:flex;justify-content:center;align-items:center;color:", ";"], props => {
  if (props.error && !props.isMenuOpen) return "".concat(_defaultTheme.colors.error, ";");
  if (!props.isDisabled) return "".concat(props.theme.field.icon, ";");
  return "".concat(_defaultTheme.colors.mediumGrey, ";");
});

const useOutsideAlerter = (ref, callback) => {
  function handleClickOutside(event) {
    if (ref.current && !ref.current.contains(event.target)) {
      callback();
    }
  }

  (0, _react.useEffect)(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  });
};

const Select = (_ref) => {
  let _ref$id = _ref.id,
      id = _ref$id === void 0 ? 'selectfield-id' : _ref$id,
      _ref$name = _ref.name,
      name = _ref$name === void 0 ? 'selectfield-name' : _ref$name,
      _ref$error = _ref.error,
      error = _ref$error === void 0 ? '' : _ref$error,
      _ref$options = _ref.options,
      options = _ref$options === void 0 ? [] : _ref$options,
      _ref$placeholder = _ref.placeholder,
      placeholder = _ref$placeholder === void 0 ? '' : _ref$placeholder,
      _ref$helpText = _ref.helpText,
      helpText = _ref$helpText === void 0 ? '' : _ref$helpText,
      _ref$leftIcon = _ref.leftIcon,
      leftIcon = _ref$leftIcon === void 0 ? '' : _ref$leftIcon,
      _ref$rightIconOpen = _ref.rightIconOpen,
      rightIconOpen = _ref$rightIconOpen === void 0 ? '' : _ref$rightIconOpen,
      _ref$rightIconClosed = _ref.rightIconClosed,
      rightIconClosed = _ref$rightIconClosed === void 0 ? '' : _ref$rightIconClosed,
      _ref$errorIcon = _ref.errorIcon,
      errorIcon = _ref$errorIcon === void 0 ? '' : _ref$errorIcon,
      _ref$isDisabled = _ref.isDisabled,
      isDisabled = _ref$isDisabled === void 0 ? false : _ref$isDisabled,
      selected = _ref.selected,
      setSelected = _ref.setSelected,
      props = _objectWithoutProperties(_ref, ["id", "name", "error", "options", "placeholder", "helpText", "leftIcon", "rightIconOpen", "rightIconClosed", "errorIcon", "isDisabled", "selected", "setSelected"]);

  const _useState = (0, _react.useState)(false),
        _useState2 = _slicedToArray(_useState, 2),
        isMenuOpen = _useState2[0],
        setIsMenuOpen = _useState2[1];

  const wrapperRef = (0, _react.useRef)(null);
  const animateLabel = !isDisabled || error;
  const isSelected = !!selected.value;
  useOutsideAlerter(wrapperRef, () => setIsMenuOpen(false));
  return _react.default.createElement(FieldWrapper, {
    onKeyDown: e => e.keyCode === 27 && setIsMenuOpen(false),
    ref: wrapperRef
  }, _react.default.createElement(SelectOutterWrapper, null, _react.default.createElement(SelectInnerWrapper, _extends({}, props, {
    error: error,
    isDisabled: isDisabled,
    isMenuOpen: isMenuOpen,
    tabIndex: "0",
    className: "Select__inner-wrapper",
    onClick: () => !isDisabled && setIsMenuOpen(!isMenuOpen),
    onKeyPress: event => {
      const keyCode = event.keyCode || event.which;
      if (keyCode === 13) setIsMenuOpen(!isMenuOpen);
    }
  }), leftIcon && _react.default.createElement(LeftIconWrapper, {
    error: error,
    isMenuOpen: isMenuOpen,
    isDisabled: isDisabled
  }, leftIcon), _react.default.createElement(SelectValueWrapper, {
    hasIcon: leftIcon
  }, _react.default.createElement(Placeholder, null, _react.default.createElement(Label, {
    isSelected: isSelected,
    animateLabel: animateLabel,
    isMenuOpen: isMenuOpen,
    htmlFor: id,
    error: error,
    isDisabled: isDisabled
  }, placeholder), _react.default.createElement(SelectedPlaceholder, {
    isSelected: isSelected,
    animateLabel: animateLabel,
    isMenuOpen: isMenuOpen,
    error: error
  }, selected.label || placeholder)), _react.default.createElement(SelectInputWrapper, null, _react.default.createElement(SelectInput, {
    id: id,
    name: name,
    tabIndex: "0"
  }))), _react.default.createElement(RightIconWrapper, {
    isMenuOpen: isMenuOpen,
    error: error,
    "aria-hidden": "true"
  }, isMenuOpen ? rightIconOpen : rightIconClosed)), isMenuOpen && _react.default.createElement(OptionsMenuWrapper, null, _react.default.createElement(OptionsMenuInnerWrapper, null, options.map((option, index) => {
    if (option.value) {
      return _react.default.createElement(OptionWrapper, {
        selected: option.value === selected.value,
        id: option.value,
        key: option.value,
        tabIndex: "0",
        className: "Select__option--open",
        onClick: () => {
          setSelected(option);
          setIsMenuOpen(false);
        },
        onKeyPress: event => {
          const keyCode = event.keyCode || event.which;

          if (keyCode === 13) {
            setSelected(option);
            setIsMenuOpen(false);
          }
        }
      }, option.icon && _react.default.createElement(LeftIconWrapper, null, option.icon), _react.default.createElement(Option, null, option.label));
    }

    return _react.default.createElement(OptionWrapper, {
      key: "".concat(index + 1),
      tabTindex: "0",
      onClick: () => {
        setIsMenuOpen(false);
        option.onClick();
      }
    }, option.element);
  })))), _react.default.createElement(HelpTextWrapper, {
    error: error
  }, error && _react.default.createElement(ErrorIconWrapper, null, errorIcon), _react.default.createElement(HelpText, {
    id: "syf-help-text-".concat(name),
    error: error
  }, error || helpText)));
};

var _default = Select;
exports.default = _default;