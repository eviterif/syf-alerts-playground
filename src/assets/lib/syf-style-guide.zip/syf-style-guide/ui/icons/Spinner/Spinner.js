"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const StyledSpinnerIcon = _styledComponents.default.svg.withConfig({
  displayName: "Spinner__StyledSpinnerIcon",
  componentId: "jgqc8x-0"
})(["fill:", ";"], props => props.color || props.theme.icon);

const Spinner = props => {
  const _props$height = props.height,
        height = _props$height === void 0 ? '40' : _props$height,
        _props$width = props.width,
        width = _props$width === void 0 ? '40' : _props$width,
        color = props.color,
        className = props.className;
  return React.createElement(StyledSpinnerIcon, {
    className: className,
    width: width,
    height: height,
    viewBox: "0 0 40 40",
    fill: color,
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink"
  }, React.createElement("path", {
    d: "M20 6.452c1.782 0 3.226-1.445 3.226-3.226C23.226 1.444 21.782 0 20 0s-3.226 1.444-3.226 3.226c0 1.781 1.444 3.226 3.226 3.226zM8.139 11.365c1.781 0 3.226-1.445 3.226-3.226 0-1.782-1.445-3.226-3.226-3.226-1.782 0-3.226 1.444-3.226 3.226 0 1.781 1.444 3.226 3.226 3.226zm28.635 11.86C38.556 23.226 40 21.783 40 20s-1.444-3.226-3.226-3.226c-1.781 0-3.226 1.444-3.226 3.226s1.445 3.226 3.226 3.226zm-33.548 0c1.781 0 3.226-1.443 3.226-3.225s-1.445-3.226-3.226-3.226C1.444 16.774 0 18.218 0 20s1.444 3.226 3.226 3.226zM31.86 35.088c1.782 0 3.226-1.444 3.226-3.226 0-1.781-1.444-3.226-3.226-3.226-1.781 0-3.226 1.445-3.226 3.226 0 1.782 1.445 3.226 3.226 3.226zm-23.722 0c1.781 0 3.226-1.444 3.226-3.226 0-1.781-1.445-3.226-3.226-3.226-1.782 0-3.226 1.445-3.226 3.226 0 1.782 1.444 3.226 3.226 3.226zM20 40c1.782 0 3.226-1.444 3.226-3.226 0-1.781-1.444-3.226-3.226-3.226s-3.226 1.445-3.226 3.226C16.774 38.556 18.218 40 20 40z"
  }));
};

var _default = Spinner;
exports.default = _default;