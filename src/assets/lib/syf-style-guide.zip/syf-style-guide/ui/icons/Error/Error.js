"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var React = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const StyledErrorIcon = _styledComponents.default.svg.withConfig({
  displayName: "Error__StyledErrorIcon",
  componentId: "sc-1ci4h0d-0"
})(["fill:", ";"], props => props.color || props.theme.icon);

const ErrorIcon = props => {
  const height = props.height,
        width = props.width,
        color = props.color,
        className = props.className;
  return React.createElement(StyledErrorIcon, {
    className: className,
    width: width,
    height: height,
    viewBox: "0 0 13 13",
    color: color,
    fillRule: "nonzero",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink"
  }, React.createElement("path", {
    d: "M6.5 12.5c3.313 0 6-2.686 6-6 0-3.313-2.687-6-6-6s-6 2.687-6 6c0 3.314 2.687 6 6 6zm0-1.161c-2.674 0-4.839-2.164-4.839-4.839 0-2.673 2.165-4.839 4.839-4.839 2.673 0 4.839 2.165 4.839 4.839 0 2.674-2.164 4.839-4.839 4.839zm.498-4.065c.155 0 .282-.121.29-.276l.165-3.29c.008-.166-.124-.305-.29-.305H5.837c-.166 0-.298.14-.29.305l.165 3.29c.008.155.135.276.29.276h.996zM6.5 9.84c.56 0 1.016-.456 1.016-1.016S7.06 7.806 6.5 7.806s-1.016.456-1.016 1.017c0 .56.456 1.016 1.016 1.016z"
  }));
};

var _default = ErrorIcon;
exports.default = _default;