"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const H5 = _styledComponents.default.h5.withConfig({
  displayName: "H5",
  componentId: "sc-1b4dbbe-0"
})(["font-size:", "px;line-height:", ";font-weight:", ";margin-block-start:0;margin-block-end:0;&:focus{outline:none;}"], _defaultTheme.fontSizes.medium, _defaultTheme.lineHeights.larger, props => _defaultTheme.fontWeights[props.weight || 'regular']);

var _default = H5;
exports.default = _default;