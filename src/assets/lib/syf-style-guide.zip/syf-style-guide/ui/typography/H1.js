"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const H1 = _styledComponents.default.h1.withConfig({
  displayName: "H1",
  componentId: "sc-10apbrl-0"
})(["font-size:", "px;line-height:", ";font-weight:", ";margin-block-start:0;margin-block-end:0;&:focus{outline:none;}"], _defaultTheme.fontSizes.xxxLarge, _defaultTheme.lineHeights.root, props => _defaultTheme.fontWeights[props.weight || 'regular']);

var _default = H1;
exports.default = _default;