"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const H2 = _styledComponents.default.h2.withConfig({
  displayName: "H2",
  componentId: "sc-1rwdqde-0"
})(["font-size:", "px;line-height:", ";font-weight:", ";margin-block-start:0;margin-block-end:0;&:focus{outline:none;}"], _defaultTheme.fontSizes.xxLarge, _defaultTheme.lineHeights.root, props => _defaultTheme.fontWeights[props.weight || 'regular']);

var _default = H2;
exports.default = _default;