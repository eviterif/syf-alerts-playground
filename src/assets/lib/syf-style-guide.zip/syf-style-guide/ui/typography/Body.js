"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const Body = (0, _styledComponents.default)(props => {
  const isInline = props.isInline,
        children = props.children,
        className = props.className;
  return isInline ? _react.default.createElement("span", {
    className: className
  }, children) : _react.default.createElement("p", {
    className: className
  }, children);
}).withConfig({
  displayName: "Body",
  componentId: "lwvsb1-0"
})(["font-size:", "px;line-height:", ";font-weight:", ";margin:0;&:focus{outline:none;}"], _defaultTheme.fontSizes.root, _defaultTheme.lineHeights.root, props => _defaultTheme.fontWeights[props.weight || 'regular']);
var _default = Body;
exports.default = _default;