"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _defaultTheme = require("../../defaultTheme");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const H4 = _styledComponents.default.h4.withConfig({
  displayName: "H4",
  componentId: "sc-1uxvul9-0"
})(["font-size:", "px;line-height:", ";font-weight:", ";margin-block-start:0;margin-block-end:0;&:focus{outline:none;}"], _defaultTheme.fontSizes.large, _defaultTheme.lineHeights.root, props => _defaultTheme.fontWeights[props.weight || 'regular']);

var _default = H4;
exports.default = _default;