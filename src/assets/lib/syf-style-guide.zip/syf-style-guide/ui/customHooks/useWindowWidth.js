"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = require("react");

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

let timerId; // a Util function that will convert the absolute width into breakpoints

function getBreakPoint(windowWidth) {
  const windowSize = {
    isLessThanMobile: false,
    isLessThanTablet: false,
    isLessThanDesktop: false,
    isLessThanXLarge: false,
    width: 0
  };

  if (windowWidth) {
    windowSize.width = windowWidth;

    if (windowWidth < 480) {
      windowSize.isLessThanMobile = true;
    }

    if (windowWidth < 768) {
      windowSize.isLessThanTablet = true;
    }

    if (windowWidth < 1024) {
      windowSize.isLessThanDesktop = true;
    }

    if (windowWidth < 1440) {
      windowSize.isLessThanXLarge = true;
    }

    return windowSize;
  }

  return windowSize;
}

const useWindowSize = () => {
  const isWindowClient = typeof window === 'object';

  const _useState = (0, _react.useState)(isWindowClient ? getBreakPoint(window.innerWidth) : {}),
        _useState2 = _slicedToArray(_useState, 2),
        windowSize = _useState2[0],
        setWindowSize = _useState2[1];

  const debounce = (func, delay) => {
    clearTimeout(timerId);
    timerId = setTimeout(func, delay);
  };

  (0, _react.useEffect)(() => {
    // a handler which will be called on change of the screen resize
    const setSize = () => {
      setWindowSize(getBreakPoint(window.innerWidth));
    };

    if (isWindowClient) {
      // register the window resize listener
      window.addEventListener('resize', () => {
        debounce(setSize, 300);
      }); // unregister the listerner on destroy of the hook

      return () => window.removeEventListener('resize', setSize);
    }

    return () => {};
  }, [isWindowClient, setWindowSize]);
  return windowSize;
};

var _default = useWindowSize;
exports.default = _default;