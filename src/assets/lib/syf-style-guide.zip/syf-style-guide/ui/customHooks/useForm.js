"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = require("react");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

const useForm = (handleSubmitCallback, validateCallback, initialValues) => {
  const _useState = (0, _react.useState)(initialValues),
        _useState2 = _slicedToArray(_useState, 2),
        form = _useState2[0],
        setForm = _useState2[1]; // for holding initial form data


  const _useState3 = (0, _react.useState)({}),
        _useState4 = _slicedToArray(_useState3, 2),
        errors = _useState4[0],
        setErrors = _useState4[1]; // for validation errors


  const _useState5 = (0, _react.useState)(false),
        _useState6 = _slicedToArray(_useState5, 2),
        success = _useState6[0],
        setSuccess = _useState6[1]; // set to true if form was submitted successfully


  const _useState7 = (0, _react.useState)(false),
        _useState8 = _slicedToArray(_useState7, 2),
        submitting = _useState8[0],
        setSubmitting = _useState8[1]; // below is a function that creates a touched variable from hte initial values of a form, setting all fields to false (not touched)


  const setInitialTouched = formData => {
    const touchedInitial = {}; // if the initial values aren't populated then return an empty object.

    if (!formData) return {}; // create a new object using the keys of the form object setting alll values to false.

    Object.keys(formData).forEach(value => {
      touchedInitial[value] = false;
    });
    return touchedInitial;
  };

  const _useState9 = (0, _react.useState)(() => setInitialTouched(initialValues)),
        _useState10 = _slicedToArray(_useState9, 2),
        touched = _useState10[0],
        setTouched = _useState10[1];

  const validate = () => {
    const error = validateCallback(form, touched);
    setErrors(error);
    return error;
  };

  const handleChange = e => {
    const _e$currentTarget = e.currentTarget,
          name = _e$currentTarget.name,
          value = _e$currentTarget.value,
          type = _e$currentTarget.type; // use destructuring ot get name/value from currentTarget for ease of use

    setForm(state => {
      // here we use the spread operator to return the object. This puts the properties of
      // state into a new object and then adds on the newly created values
      if (type === 'checkbox') {
        return _objectSpread({}, state, {
          [name]: !form[name]
        });
      }

      return _objectSpread({}, state, {
        [name]: value
      });
    });
  };

  const handleBlur = e => {
    const name = e.currentTarget.name;
    setTouched(currentState => {
      return _objectSpread({}, currentState, {
        [name]: true
      });
    });
  };

  const handleSubmit = e => {
    e.preventDefault(); // set all fields to touched

    const touchedTrue = {};
    Object.keys(form).forEach(value => {
      touchedTrue[value] = true;
    });
    setTouched(touchedTrue);
    setSubmitting(true);
  };

  (0, _react.useEffect)(() => {
    // this useEffect watches the touched values in state and will run validation if any fields are touched
    Object.values(touched).some(value => {
      if (value === true) return validate();
      return null;
    });
  }, [touched]);
  (0, _react.useEffect)(() => {
    if (submitting && Object.keys(errors).length !== 0) {
      // if there are no errors, set submitting=false and submit form.
      setSubmitting(false);
      setSuccess(false);
    } else if (submitting) {
      setSubmitting(false);
      setSuccess(handleSubmitCallback());
    }
  }, [errors]);
  return {
    handleChange,
    handleBlur,
    handleSubmit,
    setForm,
    form,
    errors,
    touched,
    submitting,
    success
  };
};

var _default = useForm;
exports.default = _default;