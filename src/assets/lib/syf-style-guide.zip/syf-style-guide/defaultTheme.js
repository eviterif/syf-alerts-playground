"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.consumerTheme = exports.colors = exports.fontWeights = exports.lineHeights = exports.fontSizes = exports.opacities = void 0;
const opacities = {
  light12: 0.12,
  light24: 0.24,
  light38: 0.38,
  halfOpacity: 0.5,
  dark70: 0.7,
  dark87: 0.87,
  noOpacity: 1.0
};
/**
 * all font-sizes should be in pixel values
 */

exports.opacities = opacities;
const fontSizes = {
  small: 12,
  root: 16,
  medium: 20,
  large: 24,
  xLarge: 28,
  xxLarge: 32,
  xxxLarge: 44
};
exports.fontSizes = fontSizes;
const lineHeights = {
  root: 1.5,
  large: 1.57,
  larger: 1.6,
  largest: 1.67
};
exports.lineHeights = lineHeights;
const fontWeights = {
  light: 300,
  regular: 400,
  semiBold: 600,
  bold: 700,
  extraBold: 800
};
exports.fontWeights = fontWeights;
const colors = {
  black: '#333333',
  error: '#C63527',
  success: '#3E8529',
  warning: '#FEB600',
  info: '#0072AD',
  white: '#FFFFFF',
  lighterGrey: '#f4f4f4',
  lightestGrey: '#F6F6F6',
  lightGrey: '#E0E0E0',
  heavyGrey: '#9E9E9E',
  mediumGrey: '#656565',
  grey: '#cdcdcd',
  lightBlue: '#e5f6ff'
};
exports.colors = colors;
const consumerTheme = {
  body: '#333333',
  link: '#34657F',
  icon: '#34657F',
  button: {
    primary: {
      text: '#FFFFFF',
      hover: '#2A5166',
      active: '#244759'
    },
    // text and icon color -- font-size
    secondary: {
      text: '#34657F',
      hover: '#EBF0F2',
      active: '#D6E0E5'
    },
    // text and icon color -- font-size
    background: '#34657F' // sets bg and border

  },
  field: {
    icon: '#34657F',
    focus: '#34657F',
    label: '#34657F',
    background: '#EEF6F7' // for select

  },
  // selects/textfields/textarea
  checkbox: {
    border: '#34657F',
    background: '#34657F',
    font: '#FFFFFF'
  },
  chip: {
    hover: '#ffe5ad',
    text: '#34657F'
  },
  switch: {
    background: '#34657F'
  },
  radio: {
    border: '#34657F',
    background: '#34657F'
  },
  navigation: {
    activeTabText: '#34657F',
    activeTabBorder: '#34657F',
    dropdownHover: '#EEF6F7'
  },
  datepicker: {
    dueDate: '#CDE5E7',
    selectedDate: '#34657F',
    selectedDateText: '#FFFFFF'
  },
  tooltip: {
    // this is consumed through component vs through theme provider
    border: '#34657F',
    background: '#EEF6F7',
    button: '#0072ad'
  },
  footer: {
    background: '#3B3C43',
    text: '#FFFFFF',
    border: ''
  },
  header: {
    background: '#F6F6F6',
    // headerBackground
    text: '',
    border: '' // just dsecurity: headerDivider

  },
  loader: '#34657F',
  // this is consumed through component vs through theme provider
  progressStepBar: {
    fill: '#34657F',
    hover: '#D6E0E5'
  },
  toasts: {
    warning: {
      font: '#B08B00',
      icon: '#B08B00',
      iconBackground: '#FBC600',
      background: '#FEF4CC'
    },
    success: {
      font: '#3E8529',
      icon: '#2B5D1D',
      iconBackground: '#3E8529',
      background: '#ECF3EA'
    },
    info: {
      font: '#34657F',
      icon: '#244759',
      iconBackground: '#34657F',
      background: '#EEF6F7'
    },
    error: {
      font: '#C63527',
      icon: '#8B251B',
      iconBackground: '#C63527',
      background: '#F9EBE9'
    }
  },
  messaging: {
    warning: {
      font: '#B08B00',
      background: '#FFF9E6'
    },
    success: {
      font: '#3E8529',
      background: '#ECF3EA'
    },
    info: {
      font: '#34657F',
      background: '##EEF6F7'
    },
    error: {
      font: '#C63527',
      background: '#FFF9E6'
    }
  },
  alertBar: {
    warning: {
      font: '#333333',
      background: '#FBC600'
    },
    success: {
      font: '#333333',
      background: '#D8E7D4'
    },
    info: {
      font: '#333333',
      background: '#CDE5E7'
    },
    default: {
      font: '#333333',
      background: '#F4F4F4'
    }
  },
  dataTable: {
    hover: '#f7fafc'
  }
};
exports.consumerTheme = consumerTheme;