"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _styledComponents = require("styled-components");

var _defaultTheme = require("./defaultTheme");

function _templateObject() {
  const data = _taggedTemplateLiteral(["\n  body, input {\n    font-family: 'Open Sans';\n    color: ", ";\n  }\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }

const GlobalStyles = (0, _styledComponents.createGlobalStyle)(_templateObject(), _defaultTheme.colors.black);
var _default = GlobalStyles;
exports.default = _default;